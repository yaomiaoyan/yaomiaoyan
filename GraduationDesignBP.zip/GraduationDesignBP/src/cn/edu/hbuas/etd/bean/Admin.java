package cn.edu.hbuas.etd.bean;

public class Admin {
    private String aId;

    private String aPwd;

    private String aName;

    private String aGender;

    private Long aPhone;

    private String aMail;

	public String getaId() {
		return aId;
	}

	public void setaId(String aId) {
		this.aId = aId;
	}

	public String getaPwd() {
		return aPwd;
	}

	public void setaPwd(String aPwd) {
		this.aPwd = aPwd;
	}

	public String getaName() {
		return aName;
	}

	public void setaName(String aName) {
		this.aName = aName;
	}

	public String getaGender() {
		return aGender;
	}

	public void setaGender(String aGender) {
		this.aGender = aGender;
	}

	public Long getaPhone() {
		return aPhone;
	}

	public void setaPhone(Long aPhone) {
		this.aPhone = aPhone;
	}

	public String getaMail() {
		return aMail;
	}

	public void setaMail(String aMail) {
		this.aMail = aMail;
	}
    
}