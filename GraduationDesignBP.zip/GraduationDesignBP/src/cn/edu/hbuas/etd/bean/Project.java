package cn.edu.hbuas.etd.bean;

public class Project {

	private Integer id;				// id
	private String code;			// 项目编号
	private String name;			// 项目名称
	private String studentCode;		// 负责人学号
	private String studentName;		// 负责人姓名
	private String member;			// 成员
	private String teacherCode;		// 指导教师编号
	private String teacherName;		// 指导教师姓名
	private String startTime;		// 项目开始时间
	private String endTime;			// 项目结束时间
	private String funding;			// 项目经费
	private String oneUrl;			// 申请书
	private String twoUrl;			// 中期文档
	private String threeUrl;		// 结项申请书
	private Integer process;		// 当前进程 1立项阶段 2 中期阶段 3 结项阶段
	private Integer status;			// 状态 0 待确定 1 同意 2 反对
	private Integer siDelete;		// 是否删除0 否 1 是
	private java.util.Date addTime;	// 添加时间

	public Integer getId() {
		return this.id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getCode() {
		return this.code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getStudentCode() {
		return this.studentCode;
	}
	
	public void setStudentCode(String studentCode) {
		this.studentCode = studentCode;
	}
	
	public String getStudentName() {
		return this.studentName;
	}
	
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	
	public String getMember() {
		return this.member;
	}
	
	public void setMember(String member) {
		this.member = member;
	}
	
	public String getTeacherCode() {
		return this.teacherCode;
	}
	
	public void setTeacherCode(String teacherCode) {
		this.teacherCode = teacherCode;
	}
	
	public String getTeacherName() {
		return this.teacherName;
	}
	
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	
	public String getStartTime() {
		return this.startTime;
	}
	
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	
	public String getEndTime() {
		return this.endTime;
	}
	
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	
	public String getFunding() {
		return this.funding;
	}
	
	public void setFunding(String funding) {
		this.funding = funding;
	}
	
	public String getOneUrl() {
		return this.oneUrl;
	}
	
	public void setOneUrl(String oneUrl) {
		this.oneUrl = oneUrl;
	}
	
	public String getTwoUrl() {
		return this.twoUrl;
	}
	
	public void setTwoUrl(String twoUrl) {
		this.twoUrl = twoUrl;
	}
	
	public String getThreeUrl() {
		return this.threeUrl;
	}
	
	public void setThreeUrl(String threeUrl) {
		this.threeUrl = threeUrl;
	}
	
	public Integer getProcess() {
		return this.process;
	}
	
	public void setProcess(Integer process) {
		this.process = process;
	}
	
	public Integer getStatus() {
		return this.status;
	}
	
	public void setStatus(Integer status) {
		this.status = status;
	}
	
	public Integer getSiDelete() {
		return this.siDelete;
	}
	
	public void setSiDelete(Integer siDelete) {
		this.siDelete = siDelete;
	}
	
	public java.util.Date getAddTime() {
		return this.addTime;
	}
	
	public void setAddTime(java.util.Date addTime) {
		this.addTime = addTime;
	}	
	
	
    public Project() {
		
	}

	public Project(Integer id ,String code ,String name ,String studentCode ,String studentName ,String member ,String teacherCode ,String teacherName ,String startTime ,String endTime ,String funding ,String oneUrl ,String twoUrl ,String threeUrl ,Integer process ,Integer status ,Integer siDelete ,java.util.Date addTime ){
	super();
	this.id=id;
	this.code=code;
	this.name=name;
	this.studentCode=studentCode;
	this.studentName=studentName;
	this.member=member;
	this.teacherCode=teacherCode;
	this.teacherName=teacherName;
	this.startTime=startTime;
	this.endTime=endTime;
	this.funding=funding;
	this.oneUrl=oneUrl;
	this.twoUrl=twoUrl;
	this.threeUrl=threeUrl;
	this.process=process;
	this.status=status;
	this.siDelete=siDelete;
	this.addTime=addTime;
	}
	
	@Override
	public String toString() {
		return "Project [id="+ id + ",code="+ code + ",name="+ name + ",studentCode="+ studentCode + ",studentName="+ studentName + ",member="+ member + ",teacherCode="+ teacherCode + ",teacherName="+ teacherName + ",startTime="+ startTime + ",endTime="+ endTime + ",funding="+ funding + ",oneUrl="+ oneUrl + ",twoUrl="+ twoUrl + ",threeUrl="+ threeUrl + ",process="+ process + ",status="+ status + ",siDelete="+ siDelete + ",addTime="+ addTime +  "]";
	}


}

