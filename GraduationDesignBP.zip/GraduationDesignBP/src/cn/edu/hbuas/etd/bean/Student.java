package cn.edu.hbuas.etd.bean;

public class Student {
    private String sId;
    
    private Integer sUser;

    private String sPwd;

    private String sName;

    private String sGender;

    private Integer sCollegeId;
    
    private String college;

    private Integer sMajorId;
    
    private String major;

    private Long sPhone;

    private String sMail;

    public String getsId() {
        return sId;
    }

    public void setsId(String sId) {
        this.sId = sId;
    }

    public Integer getsUser() {
		return sUser;
	}

	public void setsUser(Integer sUser) {
		this.sUser = sUser;
	}

	public String getsPwd() {
        return sPwd;
    }

    public void setsPwd(String sPwd) {
        this.sPwd = sPwd == null ? null : sPwd.trim();
    }

    public String getsName() {
        return sName;
    }

    public void setsName(String sName) {
        this.sName = sName == null ? null : sName.trim();
    }

    public String getsGender() {
        return sGender;
    }

    public void setsGender(String sGender) {
        this.sGender = sGender == null ? null : sGender.trim();
    }

    public Integer getsCollegeId() {
        return sCollegeId;
    }

    public String getCollege() {
		return college;
	}

	public void setCollege(String college) {
		this.college = college;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public void setsCollegeId(Integer sCollegeId) {
        this.sCollegeId = sCollegeId;
    }

    public Integer getsMajorId() {
        return sMajorId;
    }

    public void setsMajorId(Integer sMajorId) {
        this.sMajorId = sMajorId;
    }

    public Long getsPhone() {
        return sPhone;
    }

    public void setsPhone(Long sPhone) {
        this.sPhone = sPhone;
    }

    public String getsMail() {
        return sMail;
    }

    public void setsMail(String sMail) {
        this.sMail = sMail == null ? null : sMail.trim();
    }
    
}