package cn.edu.hbuas.etd.bean;

public class Teacher {
    private String tId;
    
    private Integer tUser;

    private String tPwd;

    private String tName;

    private String tGender;

    private Integer tCollegeId;
    
    private String college;

    private Integer tMajorId;
    
    private String major;

    private Long tPhone;

    private String tMail;

	public String gettId() {
		return tId;
	}

	public void settId(String tId) {
		this.tId = tId;
	}

	public Integer gettUser() {
		return tUser;
	}

	public void settUser(Integer tUser) {
		this.tUser = tUser;
	}

	public String gettPwd() {
		return tPwd;
	}

	public void settPwd(String tPwd) {
		this.tPwd = tPwd;
	}

	public String gettName() {
		return tName;
	}

	public void settName(String tName) {
		this.tName = tName;
	}

	public String gettGender() {
		return tGender;
	}

	public void settGender(String tGender) {
		this.tGender = tGender;
	}

	public Integer gettCollegeId() {
		return tCollegeId;
	}

	public void settCollegeId(Integer tCollegeId) {
		this.tCollegeId = tCollegeId;
	}

	public String getCollege() {
		return college;
	}

	public void setCollege(String college) {
		this.college = college;
	}

	public Integer gettMajorId() {
		return tMajorId;
	}

	public void settMajorId(Integer tMajorId) {
		this.tMajorId = tMajorId;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public Long gettPhone() {
		return tPhone;
	}

	public void settPhone(Long tPhone) {
		this.tPhone = tPhone;
	}

	public String gettMail() {
		return tMail;
	}

	public void settMail(String tMail) {
		this.tMail = tMail;
	}

    
    
}