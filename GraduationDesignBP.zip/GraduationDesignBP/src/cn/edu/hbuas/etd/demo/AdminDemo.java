package cn.edu.hbuas.etd.demo;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.edu.hbuas.etd.bean.Admin;
import cn.edu.hbuas.etd.service.AdminService;

public class AdminDemo {
	public static void main(String[] args) throws IOException, ParseException {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"classpath:spring/mybatis-spring.xml");
		
		
		// 添加管理员
		Admin admin = new Admin();

		admin.setaId("2015111005");
		admin.setaPwd("123456");
		admin.setaName("李莉1");
		admin.setaGender("女");
		admin.setaPhone(13411110005l);
		admin.setaMail("0005@mail.com");
		

		AdminService adminService = (AdminService) context
				.getBean("adminService");

		adminService.addAdmin(admin);

		System.out.println("添加了管理员");
		System.out.println();
		context.close();

		// 删除管理员
		/*String aIds[] = {"27dd57d867ee11e9a5ebe86a647a1b24","287c111c67ee11e9a5ebe86a647a1b24"};
		AdminService adminService = (AdminService) context
				.getBean("adminService");

		adminService.deleteAdmins(aIds);

		System.out.println("删除了管理员");
		System.out.println();
		context.close();*/
		
		// 修改管理员
		/*Admin admin = new Admin();
		AdminService adminService = (AdminService) context.
				getBean("adminService");
		
		admin = adminService.selectAdmin(3);
		
		admin.setsUser(2015111333);
		admin.setsPwd("46423");
		admin.setsName("张三");
		admin.setsGender("男");
		admin.setsCollege("教育学院");
		admin.setsMajor("教育技术学");
		admin.setsPhone(13411113333l);
		admin.setsMail("admin@mail.com");
		
		adminService.updateAdmin(admin);
		
		System.out.println("修改了管理员");
		System.out.println("id: "+admin.getsId()+
							",学号: "+admin.getsUser()+
							",密码: "+admin.getsPwd()+
							",姓名: "+admin.getsName()+
							",性别: "+admin.getsGender()+
							",学院: "+admin.getCollege()+
							",专业: "+admin.getMajor()+
							",电话: "+admin.getsPhone()+
							",邮箱: "+admin.getsMail());
		context.close();*/
		
		// 查询管理员
		/*Admin admin = new Admin();
		AdminService adminService = (AdminService) context
				.getBean("adminService");
		
		admin = adminService.selectAdmin("3");
		
		System.out.println("id: "+admin.getsId()+
							",学号: "+admin.getsUser()+
							",密码: "+admin.getsPwd()+
							",姓名: "+admin.getsName()+
							",性别: "+admin.getsGender()+
							",学院: "+admin.getCollege()+
							",专业: "+admin.getMajor()+
							",电话: "+admin.getsPhone()+
							",邮箱: "+admin.getsMail());
		context.close();*/
		
		// 分页查询管理员
		/*Admin admin = new Admin();
		AdminService adminService = (AdminService) context.
				getBean("adminService");
		
		List<Admin> admins = adminService.selectAdminByPage(admin);
		
		for (Admin admin2 : admins) {
			System.out.println("id: "+admin2.getsId()+
								",学号: "+admin2.getsUser()+
								",密码: "+admin2.getsPwd()+
								",姓名: "+admin2.getsName()+
								",性别: "+admin2.getsGender()+
								",学院: "+admin2.getCollege()+
								",学院ID:"+admin2.getsCollegeId()+
								",专业: "+admin2.getMajor()+
								",专业ID:"+admin2.getsMajorId()+
								",电话: "+admin2.getsPhone()+
								",邮箱: "+admin2.getsMail());}
		context.close();*/
		
	}
}
