package cn.edu.hbuas.etd.demo;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.edu.hbuas.etd.bean.Announcement;
import cn.edu.hbuas.etd.service.AnnouncementService;

public class AnnouncementDemo {
	public static void main(String[] args) throws IOException, ParseException {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"classpath:spring/mybatis-spring.xml");
		
		
		// 添加公告
		Announcement announcement = new Announcement();

		announcement.setAdminId("2015111000");
		announcement.setAdminName("刘思林");
		announcement.setTitle("公告标题2！");
		announcement.setContent("这是公告内容2！");

		AnnouncementService announcementService = (AnnouncementService) context
				.getBean("announcementService");

		announcementService.addAnnouncement(announcement);

		System.out.println("添加了公告");
		System.out.println();
		context.close();

		// 删除公告
		/*String aIds[] = {"27dd57d867ee11e9a5ebe86a647a1b24","287c111c67ee11e9a5ebe86a647a1b24"};
		AnnouncementService announcementService = (AnnouncementService) context
				.getBean("announcementService");

		announcementService.deleteAnnouncements(aIds);

		System.out.println("删除了公告");
		System.out.println();
		context.close();*/
		
		// 修改公告
		/*Announcement announcement = new Announcement();
		AnnouncementService announcementService = (AnnouncementService) context.
				getBean("announcementService");
		
		announcement = announcementService.selectAnnouncement(3);
		
		announcement.setsUser(2015111333);
		announcement.setsPwd("46423");
		announcement.setsName("张三");
		announcement.setsGender("男");
		announcement.setsCollege("教育学院");
		announcement.setsMajor("教育技术学");
		announcement.setsPhone(13411113333l);
		announcement.setsMail("announcement@mail.com");
		
		announcementService.updateAnnouncement(announcement);
		
		System.out.println("修改了公告");
		System.out.println("id: "+announcement.getsId()+
							",学号: "+announcement.getsUser()+
							",密码: "+announcement.getsPwd()+
							",姓名: "+announcement.getsName()+
							",性别: "+announcement.getsGender()+
							",学院: "+announcement.getCollege()+
							",专业: "+announcement.getMajor()+
							",电话: "+announcement.getsPhone()+
							",邮箱: "+announcement.getsMail());
		context.close();*/
		
		// 查询公告
		/*Announcement announcement = new Announcement();
		AnnouncementService announcementService = (AnnouncementService) context
				.getBean("announcementService");
		
		announcement = announcementService.selectAnnouncement("3");
		
		System.out.println("id: "+announcement.getsId()+
							",学号: "+announcement.getsUser()+
							",密码: "+announcement.getsPwd()+
							",姓名: "+announcement.getsName()+
							",性别: "+announcement.getsGender()+
							",学院: "+announcement.getCollege()+
							",专业: "+announcement.getMajor()+
							",电话: "+announcement.getsPhone()+
							",邮箱: "+announcement.getsMail());
		context.close();*/
		
		// 分页查询公告
			/*Admin admin = new Admin();
				AdminService adminService = (AdminService) context.
						getBean("adminService");
				
				List<Admin> admins = adminService.selectAdminByPage(admin);
				
				for (Admin admin2 : admins) {
					System.out.println("id: "+admin2.getsId()+
										",学号: "+admin2.getsUser()+
										",密码: "+admin2.getsPwd()+
										",姓名: "+admin2.getsName()+
										",性别: "+admin2.getsGender()+
										",学院: "+admin2.getCollege()+
										",学院ID:"+admin2.getsCollegeId()+
										",专业: "+admin2.getMajor()+
										",专业ID:"+admin2.getsMajorId()+
										",电话: "+admin2.getsPhone()+
										",邮箱: "+admin2.getsMail());}
				context.close();*/
		
	}
}
