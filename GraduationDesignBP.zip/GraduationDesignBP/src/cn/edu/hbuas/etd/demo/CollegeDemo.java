package cn.edu.hbuas.etd.demo;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.edu.hbuas.etd.bean.College;
import cn.edu.hbuas.etd.service.CollegeService;

public class CollegeDemo {
	public static void main(String[] args) throws IOException, ParseException {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"classpath:spring/mybatis-spring.xml");
		
		// 查询学院
		College college = new College();
		List<College> colleges = null;
		CollegeService collegeService = (CollegeService) context
				.getBean("collegeService");
		
		colleges = collegeService.selectCollege(college);
		
		for (int i = 0; i < colleges.size(); i++) {
			
		System.out.println("学院id: "+colleges.get(i).getCollegeId()+
							",学院名: "+colleges.get(i).getCollege());
		}
		
		context.close();
		
	}
}
