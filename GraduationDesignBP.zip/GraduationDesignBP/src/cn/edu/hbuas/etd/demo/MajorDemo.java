package cn.edu.hbuas.etd.demo;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.edu.hbuas.etd.bean.Major;
import cn.edu.hbuas.etd.service.MajorService;

public class MajorDemo {
	public static void main(String[] args) throws IOException, ParseException {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"classpath:spring/mybatis-spring.xml");
		
		// 根据学院id查询专业
		List<Major> majors = null;
		MajorService majorService = (MajorService) context
				.getBean("majorService");
		
		majors = majorService.getMajorById(5);
		
		for (int i = 0; i < majors.size(); i++) {
			
		System.out.println("学院id: "+majors.get(i).getCollegeId()+
							",专业id: "+majors.get(i).getMajorId()+
							",专业名: "+majors.get(i).getMajor());
		}
		
		context.close();
		
	}
}
