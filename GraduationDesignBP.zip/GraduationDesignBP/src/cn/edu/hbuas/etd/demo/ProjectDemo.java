package cn.edu.hbuas.etd.demo;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.edu.hbuas.etd.bean.Project;
import cn.edu.hbuas.etd.service.ProjectService;

public class ProjectDemo {
	public static void main(String[] args) throws IOException, ParseException {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"classpath:spring/mybatis-spring.xml");
		
		
		// 添加项目
		/*Project project = new Project();

		project.setsUser(2015111444);
		project.setsPwd("1234567");
		project.setsName("李雷");
		project.setsGender("男");
		project.setsCollegeId(3);
		project.setsMajorId(1);
		project.setsPhone(13411114444l);
		project.setsMail("admin@mail.com");
		

		ProjectService projectService = (ProjectService) context
				.getBean("projectService");

		projectService.addProject(project);

		System.out.println("添加了项目");
		System.out.println();
		context.close();*/

		// 删除项目
		/*String sIds[] = {"27dd57d867ee11e9a5ebe86a647a1b24","287c111c67ee11e9a5ebe86a647a1b24"};
		ProjectService projectService = (ProjectService) context
				.getBean("projectService");

		projectService.deleteProjects(sIds);

		System.out.println("删除了项目");
		System.out.println();
		context.close();*/
		
		// 修改项目
		/*Project project = new Project();
		ProjectService projectService = (ProjectService) context.
				getBean("projectService");
		
		project = projectService.selectProject(3);
		
		project.setsUser(2015111333);
		project.setsPwd("46423");
		project.setsName("张三");
		project.setsGender("男");
		project.setsCollege("教育学院");
		project.setsMajor("教育技术学");
		project.setsPhone(13411113333l);
		project.setsMail("admin@mail.com");
		
		projectService.updateProject(project);
		
		System.out.println("修改了项目");
		System.out.println("id: "+project.getsId()+
							",学号: "+project.getsUser()+
							",密码: "+project.getsPwd()+
							",姓名: "+project.getsName()+
							",性别: "+project.getsGender()+
							",学院: "+project.getCollege()+
							",专业: "+project.getMajor()+
							",电话: "+project.getsPhone()+
							",邮箱: "+project.getsMail());
		context.close();*/
		
		// 查询项目
		Project project = new Project();
		ProjectService projectService = (ProjectService) context
				.getBean("projectService");
		
		project = projectService.selectProject(4);
		
		System.out.println("项目id: "+project.getId()+
							",项目编号: "+project.getCode()+
							",项目名称: "+project.getName()+
							",负责人学号: "+project.getStudentCode()+
							",负责人姓名: "+project.getStudentName()+
							",成员: "+project.getMember()+
							",指导教师编号: "+project.getTeacherCode()+
							",指导教师姓名: "+project.getTeacherName()+
							",开始时间: "+project.getStartTime()+
							",结束时间: "+project.getEndTime()+
							",经费: "+project.getFunding()+
							",申请书: "+project.getOneUrl()+
							",中期文档: "+project.getTwoUrl()+
							",结项申请书: "+project.getThreeUrl()+
							",进程: "+project.getProcess()+
							",状态: "+project.getStatus()+
							",是否删除: "+project.getSiDelete()+
							",添加时间: "+project.getAddTime());
		context.close();
		
		// 分页查询项目
		/*Project project = new Project();
		ProjectService projectService = (ProjectService) context.
				getBean("projectService");
		
		List<Project> projects = projectService.selectProjectByPage(project);
		
		for (Project project2 : projects) {
			System.out.println("id: "+project2.getsId()+
								",学号: "+project2.getsUser()+
								",密码: "+project2.getsPwd()+
								",姓名: "+project2.getsName()+
								",性别: "+project2.getsGender()+
								",学院: "+project2.getCollege()+
								",学院ID:"+project2.getsCollegeId()+
								",专业: "+project2.getMajor()+
								",专业ID:"+project2.getsMajorId()+
								",电话: "+project2.getsPhone()+
								",邮箱: "+project2.getsMail());}
		context.close();*/
		
	}
}
