package cn.edu.hbuas.etd.demo;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.edu.hbuas.etd.bean.Student;
import cn.edu.hbuas.etd.service.StudentService;

public class StudengDemo {
	public static void main(String[] args) throws IOException, ParseException {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"classpath:spring/mybatis-spring.xml");
		
		
		// 添加学生
		Student student = new Student();

		student.setsUser(2015108101);
		student.setsPwd("123456");
		student.setsName("韩梅梅");
		student.setsGender("女");
		student.setsCollegeId(2);
		student.setsMajorId(1);
		student.setsPhone(13411115555l);
		student.setsMail("123@qq.com");
		

		StudentService studentService = (StudentService) context
				.getBean("studentService");

		studentService.addStudent(student);

		System.out.println("添加了学生");
		System.out.println();
		context.close();

		// 删除学生
		/*String sIds[] = {"21","31"};
		StudentService studentService = (StudentService) context
				.getBean("studentService");

		studentService.deleteStudents(sIds);

		System.out.println("删除了学生");
		System.out.println();
		context.close();*/
		
		// 修改学生
		/*Student student = new Student();
		StudentService studentService = (StudentService) context.
				getBean("studentService");
		
		student = studentService.selectStudent(3);
		
		student.setsUser(2015111333);
		student.setsPwd("46423");
		student.setsName("张三");
		student.setsGender("男");
		student.setsCollege("教育学院");
		student.setsMajor("教育技术学");
		student.setsPhone(13411113333l);
		student.setsMail("admin@mail.com");
		
		studentService.updateStudent(student);
		
		System.out.println("修改了学生");
		System.out.println("id: "+student.getsId()+
							",学号: "+student.getsUser()+
							",密码: "+student.getsPwd()+
							",姓名: "+student.getsName()+
							",性别: "+student.getsGender()+
							",学院: "+student.getCollege()+
							",专业: "+student.getMajor()+
							",电话: "+student.getsPhone()+
							",邮箱: "+student.getsMail());
		context.close();*/
		
		// 查询学生
		/*Student student = new Student();
		StudentService studentService = (StudentService) context
				.getBean("studentService");
		
		student = studentService.selectStudent("2015111555");
		
		System.out.println(	"学号: "+student.getsId()+
							",密码: "+student.getsPwd()+
							",姓名: "+student.getsName()+
							",性别: "+student.getsGender()+
							",学院: "+student.getsCollegeId()+
							",专业: "+student.getsMajorId()+
							",电话: "+student.getsPhone()+
							",邮箱: "+student.getsMail());
		context.close();*/
		
		// 分页查询学生
		/*Student student = new Student();
		StudentService studentService = (StudentService) context.
				getBean("studentService");
		
		List<Student> students = studentService.selectStudentByPage(student);
		
		for (Student student2 : students) {
			System.out.println("id: "+student2.getsId()+
								",学号: "+student2.getsUser()+
								",密码: "+student2.getsPwd()+
								",姓名: "+student2.getsName()+
								",性别: "+student2.getsGender()+
								",学院: "+student2.getCollege()+
								",学院ID:"+student2.getsCollegeId()+
								",专业: "+student2.getMajor()+
								",专业ID:"+student2.getsMajorId()+
								",电话: "+student2.getsPhone()+
								",邮箱: "+student2.getsMail());}
		context.close();*/
		
	}
}
