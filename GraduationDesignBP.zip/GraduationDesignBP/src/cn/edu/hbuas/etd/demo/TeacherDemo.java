package cn.edu.hbuas.etd.demo;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.edu.hbuas.etd.bean.Teacher;
import cn.edu.hbuas.etd.service.TeacherService;

public class TeacherDemo {
	public static void main(String[] args) throws IOException, ParseException {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"classpath:spring/mybatis-spring.xml");
		
		
		// 添加教师
		Teacher teacher = new Teacher();

		teacher.settUser(2015111444);
		teacher.settPwd("1234567");
		teacher.settName("李雷");
		teacher.settGender("男");
		teacher.settCollegeId(3);
		teacher.settMajorId(1);
		teacher.settPhone(13411114444l);
		teacher.settMail("admin@mail.com");
		

		TeacherService teacherService = (TeacherService) context
				.getBean("teacherService");

		teacherService.addTeacher(teacher);

		System.out.println("添加了教师");
		System.out.println();
		context.close();

		// 删除教师
		/*String tIds[] = {"2015111000","2015111001"};
		TeacherService teacherService = (TeacherService) context
				.getBean("teacherService");

		teacherService.deleteTeachers(tIds);

		System.out.println("删除了教师");
		System.out.println();
		context.close();*/
		
		// 修改教师
		/*Teacher teacher = new Teacher();
		TeacherService teacherService = (TeacherService) context.
				getBean("teacherService");
		
		teacher = teacherService.selectTeacher(3);
		
		teacher.settId(2015111000);
		teacher.settPwd("46423");
		teacher.settName("张三");
		teacher.settGender("男");
		teacher.settCollege("教育学院");
		teacher.settMajor("教育技术学");
		teacher.settPhone(13411113333l);
		teacher.settMail("admin@mail.com");
		
		teacherService.updateTeacher(teacher);
		
		System.out.println("修改了教师");
		System.out.println("id: "+teacher.getsId()+
							",学号: "+teacher.getsUser()+
							",密码: "+teacher.getsPwd()+
							",姓名: "+teacher.getsName()+
							",性别: "+teacher.getsGender()+
							",学院: "+teacher.getCollege()+
							",专业: "+teacher.getMajor()+
							",电话: "+teacher.getsPhone()+
							",邮箱: "+teacher.getsMail());
		context.close();*/
		
		// 查询教师
		/*Teacher teacher = new Teacher();
		TeacherService teacherService = (TeacherService) context
				.getBean("teacherService");
		
		teacher = teacherService.selectTeacher("3");
		
		System.out.println("id: "+teacher.getsId()+
							",学号: "+teacher.getsUser()+
							",密码: "+teacher.getsPwd()+
							",姓名: "+teacher.getsName()+
							",性别: "+teacher.getsGender()+
							",学院: "+teacher.getCollege()+
							",专业: "+teacher.getMajor()+
							",电话: "+teacher.getsPhone()+
							",邮箱: "+teacher.getsMail());
		context.close();*/
		
		// 分页查询教师
		/*Teacher teacher = new Teacher();
		TeacherService teacherService = (TeacherService) context.
				getBean("teacherService");
		
		List<Teacher> teachers = teacherService.selectTeacherByPage(teacher);
		
		for (Teacher teacher2 : teachers) {
			System.out.println("id: "+teacher2.getsId()+
								",学号: "+teacher2.getsUser()+
								",密码: "+teacher2.getsPwd()+
								",姓名: "+teacher2.getsName()+
								",性别: "+teacher2.getsGender()+
								",学院: "+teacher2.getCollege()+
								",学院ID:"+teacher2.getsCollegeId()+
								",专业: "+teacher2.getMajor()+
								",专业ID:"+teacher2.getsMajorId()+
								",电话: "+teacher2.getsPhone()+
								",邮箱: "+teacher2.getsMail());}
		context.close();*/
		
	}
}
