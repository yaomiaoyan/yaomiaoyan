package cn.edu.hbuas.etd.mapper;

import java.util.List;
import org.springframework.stereotype.Repository;
import cn.edu.hbuas.etd.bean.Admin;

// 映射器接口
@Repository("adminMapper")
public interface AdminMapper {
	
	/*添加管理员*/
	public void addAdmin (Admin admin);
	
	/*删除、批量删除管理员*/
	public void deleteAdmins (String[] aIds);
	
	/*修改管理员*/
	public void updateAdmin (Admin admin);
	
	/*查询管理员*/
	public Admin selectAdmin (String aId);
	
	/*分页查询管理员*/
	public List<Admin> selectAdminByPage (Admin admin);
}
