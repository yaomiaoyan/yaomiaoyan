package cn.edu.hbuas.etd.mapper;

import java.util.List;

import org.springframework.stereotype.Repository;

import cn.edu.hbuas.etd.bean.Admin;
import cn.edu.hbuas.etd.bean.Announcement;

// 映射器接口
@Repository("announcementMapper")
public interface AnnouncementMapper {
	
	/*添加公告*/
	public void addAnnouncement (Announcement announcement);
	
	/*删除、批量删除公告*/
	public void deleteAnnouncements (String[] ids);
	
	/*修改公告*/
	public void updateAnnouncement (Announcement announcement);
	
	/*查询公告*/
	public Announcement selectAnnouncement (Integer id);
	
	/*分页查询管理员*/
	public List<Announcement> selectAnnouncementByPage (Announcement announcement);
	
}
