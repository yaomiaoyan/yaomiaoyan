package cn.edu.hbuas.etd.mapper;

import java.util.List;
import org.springframework.stereotype.Repository;
import cn.edu.hbuas.etd.bean.College;

// 映射器接口
@Repository("collegeMapper")
public interface CollegeMapper {
	
	/*遍历学院*/
	public List<College> selectCollege(College college);
	
}
