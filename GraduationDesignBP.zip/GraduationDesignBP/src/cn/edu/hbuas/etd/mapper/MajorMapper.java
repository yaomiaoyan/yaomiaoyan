package cn.edu.hbuas.etd.mapper;

import java.util.List;

import org.springframework.stereotype.Repository;

import cn.edu.hbuas.etd.bean.Major;

// 映射器接口
@Repository("majorMapper")
public interface MajorMapper {
	
	/*根据学院id获取专业*/
	public List<Major> getMajorById(Integer collegeId);
	
}
