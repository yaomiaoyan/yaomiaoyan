package cn.edu.hbuas.etd.mapper;

import java.util.List;
import org.springframework.stereotype.Repository;
import cn.edu.hbuas.etd.bean.Project;

// 映射器接口
@Repository("projectMapper")
public interface ProjectMapper {
	
	/*删除、批量删除项目*/
	public void deleteProjects (String[] ids);
	
	/*修改项目*/
	/*public void updateProject (Project project);*/
	
	/*查询项目*/
	public Project selectProject (Integer id);
	
	/*分页查询项目*/
	public List<Project> selectProjectByPage (Project project);
}
