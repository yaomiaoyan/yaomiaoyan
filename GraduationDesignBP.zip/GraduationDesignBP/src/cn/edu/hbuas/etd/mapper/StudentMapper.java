package cn.edu.hbuas.etd.mapper;

import java.util.List;
import org.springframework.stereotype.Repository;
import cn.edu.hbuas.etd.bean.Student;

// 映射器接口
@Repository("studentMapper")
public interface StudentMapper {
	
	/*添加学生*/
	public void addStudent (Student student);
	
	/*删除、批量删除学生*/
	public void deleteStudents (String[] sIds);
	
	/*修改学生*/
	public void updateStudent (Student student);
	
	/*查询学生*/
	public Student selectStudent (String sId);
	
	/*分页查询学生*/
	public List<Student> selectStudentByPage (Student student);
}
