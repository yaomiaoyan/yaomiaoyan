package cn.edu.hbuas.etd.mapper;

import java.util.List;
import org.springframework.stereotype.Repository;
import cn.edu.hbuas.etd.bean.Teacher;

// 映射器接口
@Repository("teacherMapper")
public interface TeacherMapper {
	
	/*添加教师*/
	public void addTeacher (Teacher teacher);
	
	/*删除、批量删除教师*/
	public void deleteTeachers (String[] tIds);
	
	/*修改教师*/
	public void updateTeacher (Teacher teacher);
	
	/*查询教师*/
	public Teacher selectTeacher (String tId);
	
	/*分页查询教师*/
	public List<Teacher> selectTeacherByPage (Teacher teacher);
}
