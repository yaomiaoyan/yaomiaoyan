package cn.edu.hbuas.etd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.hbuas.etd.bean.Admin;
import cn.edu.hbuas.etd.mapper.AdminMapper;

@Service
public class AdminService {

	@Autowired
	private AdminMapper adminMapper;
	
	// 添加管理员
	public void addAdmin (Admin admin) {
		adminMapper.addAdmin(admin);
	}

	// 根据id删除、批量删除管理员
	public void deleteAdmins (String[] aIds) {
		adminMapper.deleteAdmins(aIds);
	}
	
	// 修改管理员
	public void updateAdmin (Admin admin) {
		adminMapper.updateAdmin(admin);
	}
	
	// 查询管理员
	public Admin selectAdmin (String aId) {
		Admin adm = adminMapper.selectAdmin(aId);
		return adm;
	}
	
	// 分页查询管理员
	public List<Admin> selectAdminByPage (Admin admin) {
		List<Admin> adm = adminMapper.selectAdminByPage(admin);
		return adm;
	}
}
