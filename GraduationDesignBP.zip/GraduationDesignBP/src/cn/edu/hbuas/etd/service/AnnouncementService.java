package cn.edu.hbuas.etd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.hbuas.etd.bean.Admin;
import cn.edu.hbuas.etd.bean.Announcement;
import cn.edu.hbuas.etd.mapper.AnnouncementMapper;

@Service
public class AnnouncementService {

	@Autowired
	private AnnouncementMapper announcementMapper;
	
	// 添加公告
	public void addAnnouncement (Announcement announcement) {
		announcementMapper.addAnnouncement(announcement);
	}

	// 根据id删除、批量删除公告
	public void deleteAnnouncements (String[] ids) {
		announcementMapper.deleteAnnouncements(ids);
	}
	
	// 修改公告
	public void updateAnnouncement (Announcement announcement) {
		announcementMapper.updateAnnouncement(announcement);
	}
	
	// 查询公告
	public Announcement selectAnnouncement (Integer id) {
		Announcement ano = announcementMapper.selectAnnouncement(id);
		return ano;
	}
	
	// 分页查询管理员
		public List<Announcement> selectAnnouncementByPage (Announcement announcement) {
			List<Announcement> ano = announcementMapper.selectAnnouncementByPage(announcement);
			return ano;
		}
}
