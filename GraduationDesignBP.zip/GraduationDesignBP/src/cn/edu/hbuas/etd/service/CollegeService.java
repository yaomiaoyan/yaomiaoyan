package cn.edu.hbuas.etd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.hbuas.etd.bean.College;
import cn.edu.hbuas.etd.mapper.CollegeMapper;

@Service
public class CollegeService {

	@Autowired
	private CollegeMapper collegeMapper;

	// 遍历学院
	public List<College> selectCollege(College college) {
		List<College> colleges = collegeMapper.selectCollege(college);
		return colleges;
	}
}
