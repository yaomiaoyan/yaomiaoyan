package cn.edu.hbuas.etd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.hbuas.etd.bean.Major;
import cn.edu.hbuas.etd.mapper.MajorMapper;

@Service
public class MajorService {

	@Autowired
	private MajorMapper majorMapper;
	
	public List<Major> getMajorById (Integer collegeId) {
		List<Major> majors = majorMapper.getMajorById(collegeId);
		return majors;
	}

}
