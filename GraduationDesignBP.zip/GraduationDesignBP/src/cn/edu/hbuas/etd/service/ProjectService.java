package cn.edu.hbuas.etd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.hbuas.etd.bean.Project;
import cn.edu.hbuas.etd.mapper.ProjectMapper;

@Service
public class ProjectService {

	@Autowired
	private ProjectMapper projectMapper;
	
	// 根据id删除、批量删除项目
	public void deleteProjects (String[] ids) {
		projectMapper.deleteProjects(ids);
	}
	
	// 修改项目
	/*public void updateProject (Project project) {
		projectMapper.updateProject(project);
	}*/
	
	// 查询项目
	public Project selectProject (Integer id) {
		Project pro = projectMapper.selectProject(id);
		return pro;
	}
	
	// 分页查询项目
	public List<Project> selectProjectByPage (Project project) {
		List<Project> pro = projectMapper.selectProjectByPage(project);
		return pro;
	}
}
