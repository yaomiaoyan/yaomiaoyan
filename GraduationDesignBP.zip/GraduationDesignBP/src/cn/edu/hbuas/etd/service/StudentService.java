package cn.edu.hbuas.etd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.hbuas.etd.bean.Student;
import cn.edu.hbuas.etd.mapper.StudentMapper;

@Service
public class StudentService {

	@Autowired
	private StudentMapper studentMapper;
	
	// 添加学生
	public void addStudent (Student student) {
		studentMapper.addStudent(student);
	}

	// 根据id删除、批量删除学生
	public void deleteStudents (String[] sIds) {
		studentMapper.deleteStudents(sIds);
	}
	
	// 修改学生
	public void updateStudent (Student student) {
		studentMapper.updateStudent(student);
	}
	
	// 查询学生
	public Student selectStudent (String sId) {
		Student stu = studentMapper.selectStudent(sId);
		return stu;
	}
	
	// 分页查询学生
	public List<Student> selectStudentByPage (Student student) {
		List<Student> stu = studentMapper.selectStudentByPage(student);
		return stu;
	}
}
