package cn.edu.hbuas.etd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.hbuas.etd.bean.Teacher;
import cn.edu.hbuas.etd.mapper.TeacherMapper;

@Service
public class TeacherService {

	@Autowired
	private TeacherMapper teacherMapper;
	
	// 添加教师
	public void addTeacher (Teacher teacher) {
		teacherMapper.addTeacher(teacher);
	}

	// 根据id删除、批量删除教师
	public void deleteTeachers (String[] tIds) {
		teacherMapper.deleteTeachers(tIds);
	}
	
	// 修改教师
	public void updateTeacher (Teacher teacher) {
		teacherMapper.updateTeacher(teacher);
	}
	
	// 查询教师
	public Teacher selectTeacher (String tId) {
		Teacher tea = teacherMapper.selectTeacher(tId);
		return tea;
	}
	
	// 分页查询教师
	public List<Teacher> selectTeacherByPage (Teacher teacher) {
		List<Teacher> tea = teacherMapper.selectTeacherByPage(teacher);
		return tea;
	}
}
