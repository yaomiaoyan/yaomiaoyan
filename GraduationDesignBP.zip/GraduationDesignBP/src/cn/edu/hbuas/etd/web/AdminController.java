package cn.edu.hbuas.etd.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.edu.hbuas.etd.bean.Admin;
import cn.edu.hbuas.etd.service.AdminService;
import cn.edu.hbuas.etd.util.LayResult;

@Controller // 标注此类为一个控制器
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	// 添加管理员
	@RequestMapping(value = "/addAdmin", method = RequestMethod.POST)
	@ResponseBody
	public void addadmin(Admin admin) {
		adminService.addAdmin(admin);
	}
	
	// 删除、批量删除管理员
	@RequestMapping(value = "/deleteAdmins", method = RequestMethod.POST)
	@ResponseBody
	public void deleteAdmins(String aIds) {
		String [] aIdss = aIds.split(",");
		adminService.deleteAdmins(aIdss);
	}
	
	// 修改管理员
	@RequestMapping(value = "/updateAdmin", method = RequestMethod.POST)
	@ResponseBody
	public void updateAdmin(Admin admin) {
		adminService.updateAdmin(admin);
	}
	
	// 查询管理员
	@RequestMapping(value = "/selectAdmin", method = RequestMethod.POST)
	@ResponseBody
	public Admin selectAdmin(String aId) {
		Admin adm = adminService.selectAdmin(aId);
		return adm;
	}
	
	/*
	 * 分页查询管理员
	 * @Param pageNam 第几页
	 * @Param pageSize 每页显示长度
	 * 
	 */
	@RequestMapping(value = "/selectAdminByPage", method = RequestMethod.POST)
	@ResponseBody
	public LayResult selectAdminByPage(int page,int limit,Admin admin) {
		LayResult result = new LayResult();
		try {
			PageHelper.startPage(page, limit);
			List<Admin> list = adminService.selectAdminByPage(admin);
			PageInfo<Admin> pageInfo = new PageInfo<Admin>(list);
			result.setCode(0);
			result.setData(list);
			result.setCount(pageInfo.getTotal());
			result.setMsg("success!");
		} catch (Exception e) {
			e.printStackTrace();
			result.setCode(1);
			result.setMsg("数据异常！");
		}
		
		return result;
	}
	
}
