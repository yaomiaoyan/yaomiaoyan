package cn.edu.hbuas.etd.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.edu.hbuas.etd.bean.Announcement;
import cn.edu.hbuas.etd.bean.Announcement;
import cn.edu.hbuas.etd.service.AnnouncementService;
import cn.edu.hbuas.etd.util.LayResult;

@Controller // 标注此类为一个控制器
public class AnnouncementController {
	
	@Autowired
	private AnnouncementService announcementService;
	
	// 添加公告
	@RequestMapping(value = "/addAnnouncement", method = RequestMethod.POST)
	@ResponseBody
	public void addannouncement(Announcement announcement) {
		announcementService.addAnnouncement(announcement);
	}
	
	// 删除、批量删除公告
	@RequestMapping(value = "/deleteAnnouncements", method = RequestMethod.POST)
	@ResponseBody
	public void deleteAnnouncements(String ids) {
		String [] idss = ids.split(",");
		announcementService.deleteAnnouncements(idss);
	}
	
	// 修改公告
	@RequestMapping(value = "/updateAnnouncement"/*, method = RequestMethod.POST*/)
	@ResponseBody
	public void updateAnnouncement(Announcement announcement) {
		announcementService.updateAnnouncement(announcement);
	}
	
	// 查询公告
	@RequestMapping(value = "/selectAnnouncement"/*, method = RequestMethod.POST*/)
	@ResponseBody
	public Announcement selectAnnouncement(Integer id) {
		Announcement ano = announcementService.selectAnnouncement(id);
		return ano;
	}
	
	/*
	 * 分页查询管理员
	 * @Param pageNam 第几页
	 * @Param pageSize 每页显示长度
	 * 
	 */
	@RequestMapping(value = "/selectAnnouncementByPage", method = RequestMethod.POST)
	@ResponseBody
	public LayResult selectAnnouncementByPage(int page,int limit,Announcement announcement) {
		LayResult result = new LayResult();
		try {
			PageHelper.startPage(page, limit);
			List<Announcement> list = announcementService.selectAnnouncementByPage(announcement);
			PageInfo<Announcement> pageInfo = new PageInfo<Announcement>(list);
			result.setCode(0);
			result.setData(list);
			result.setCount(pageInfo.getTotal());
			result.setMsg("success!");
		} catch (Exception e) {
			e.printStackTrace();
			result.setCode(1);
			result.setMsg("数据异常！");
		}
		
		return result;
	}
	
}
