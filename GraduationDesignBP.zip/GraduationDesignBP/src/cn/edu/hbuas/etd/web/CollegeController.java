package cn.edu.hbuas.etd.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.edu.hbuas.etd.bean.College;
import cn.edu.hbuas.etd.bean.Major;
import cn.edu.hbuas.etd.service.CollegeService;
import cn.edu.hbuas.etd.service.MajorService;

@Controller // 标注此类为一个控制器
public class CollegeController {
	
	@Autowired
	private CollegeService collegeService;
	
	@RequestMapping(value = "/colleges", method = RequestMethod.POST)
	@ResponseBody
	public List<College> college(College college) {
		List<College> colleges = collegeService.selectCollege(college);
		return colleges;
	}
	
	@Autowired
	private MajorService majorService;
	
	@RequestMapping(value = "/majors", method = RequestMethod.POST)
	@ResponseBody
	public List<Major> major(Integer collegeId) {
		List<Major> majors = majorService.getMajorById(collegeId);
		return majors;
	}
}
