package cn.edu.hbuas.etd.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.edu.hbuas.etd.bean.Project;
import cn.edu.hbuas.etd.service.ProjectService;
import cn.edu.hbuas.etd.util.LayResult;

@Controller // 标注此类为一个控制器
public class ProjectController {
	
	@Autowired
	private ProjectService projectService;
	
	// 删除、批量删除项目
	@RequestMapping(value = "/deleteProjects", method = RequestMethod.POST)
	@ResponseBody
	public void deleteProjects(String ids) {
		String [] idss = ids.split(",");
		projectService.deleteProjects(idss);
	}
	
	// 修改项目
	/*@RequestMapping(value = "/updateProject", method = RequestMethod.POST)
	@ResponseBody
	public void updateProject(Project project) {
		projectService.updateProject(project);
	}*/
	
	// 查询项目
	@RequestMapping(value = "/selectProject", method = RequestMethod.POST)
	@ResponseBody
	public Project selectProject(Integer id) {
		Project pro = projectService.selectProject(id);
		return pro;
	}
	
	/*
	 * 分页查询项目
	 * @Param pageNam 第几页
	 * @Param pageSize 每页显示长度
	 * 
	 */
	@RequestMapping(value = "/selectProjectByPage", method = RequestMethod.POST)
	@ResponseBody
	public LayResult selectProjectByPage(int page,int limit,Project project) {
		LayResult result = new LayResult();
		try {
			PageHelper.startPage(page, limit);
			List<Project> list = projectService.selectProjectByPage(project);
			PageInfo<Project> pageInfo = new PageInfo<Project>(list);
			result.setCode(0);
			result.setData(list);
			result.setCount(pageInfo.getTotal());
			result.setMsg("success!");
		} catch (Exception e) {
			e.printStackTrace();
			result.setCode(1);
			result.setMsg("数据异常！");
		}
		
		return result;
	}
	
}
