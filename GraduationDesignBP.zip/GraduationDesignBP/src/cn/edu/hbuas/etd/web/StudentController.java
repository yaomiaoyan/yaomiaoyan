package cn.edu.hbuas.etd.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.edu.hbuas.etd.bean.Student;
import cn.edu.hbuas.etd.service.StudentService;
import cn.edu.hbuas.etd.util.LayResult;

@Controller // 标注此类为一个控制器
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	// 添加学生
	@RequestMapping(value = "/addStudent", method = RequestMethod.POST)
	@ResponseBody
	public void addstudent(Student student) {
		studentService.addStudent(student);
	}
	
	// 删除、批量删除学生
	@RequestMapping(value = "/deleteStudents", method = RequestMethod.POST)
	@ResponseBody
	public void deleteStudents(String sIds) {
		String [] sIdss=sIds.split(",");
		studentService.deleteStudents(sIdss);
	}
	
	// 修改学生
	@RequestMapping(value = "/updateStudent", method = RequestMethod.POST)
	@ResponseBody
	public void updateStudent(Student student) {
		studentService.updateStudent(student);
	}
	
	// 查询学生
	@RequestMapping(value = "/selectStudent", method = RequestMethod.POST)
	@ResponseBody
	public Student selectStudent(String sId) {
		Student stu = studentService.selectStudent(sId);
		return stu;
	}
	
	/*
	 * 分页查询学生
	 * @Param pageNam 第几页
	 * @Param pageSize 每页显示长度
	 * 
	 */
	@RequestMapping(value = "/selectStudentByPage", method = RequestMethod.POST)
	@ResponseBody
	public LayResult selectStudentByPage(int page,int limit,Student student) {
		LayResult result = new LayResult();
		try {
			PageHelper.startPage(page, limit);
			List<Student> list = studentService.selectStudentByPage(student);
			PageInfo<Student> pageInfo = new PageInfo<Student>(list);
			result.setCode(0);
			result.setData(list);
			result.setCount(pageInfo.getTotal());
			result.setMsg("success!");
		} catch (Exception e) {
			e.printStackTrace();
			result.setCode(1);
			result.setMsg("数据异常！");
		}
		
		return result;
	}
	
}
