package cn.edu.hbuas.etd.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.edu.hbuas.etd.bean.Teacher;
import cn.edu.hbuas.etd.service.TeacherService;
import cn.edu.hbuas.etd.util.LayResult;

@Controller // 标注此类为一个控制器
public class TeacherController {
	
	@Autowired
	private TeacherService teacherService;
	
	// 添加教师
	@RequestMapping(value = "/addTeacher", method = RequestMethod.POST)
	@ResponseBody
	public void addteacher(Teacher teacher) {
		teacherService.addTeacher(teacher);
	}
	
	// 删除、批量删除教师
	@RequestMapping(value = "/deleteTeachers", method = RequestMethod.POST)
	@ResponseBody
	public void deleteTeachers(String tIds) {
		String [] tIdss = tIds.split(",");
		teacherService.deleteTeachers(tIdss);
	}
	
	// 修改教师
	@RequestMapping(value = "/updateTeacher"/*, method = RequestMethod.POST*/)
	@ResponseBody
	public void updateTeacher(Teacher teacher) {
		teacherService.updateTeacher(teacher);
	}
	
	// 查询教师
	@RequestMapping(value = "/selectTeacher"/*, method = RequestMethod.POST*/)
	@ResponseBody
	public Teacher selectTeacher(String tId) {
		Teacher tea = teacherService.selectTeacher(tId);
		return tea;
	}
	
	/*
	 * 分页查询教师
	 * @Param pageNam 第几页
	 * @Param pageSize 每页显示长度
	 * 
	 */
	@RequestMapping(value = "/selectTeacherByPage", method = RequestMethod.POST)
	@ResponseBody
	public LayResult selectTeacherByPage(int page,int limit,Teacher teacher) {
		LayResult result = new LayResult();
		try {
			PageHelper.startPage(page, limit);
			List<Teacher> list = teacherService.selectTeacherByPage(teacher);
			PageInfo<Teacher> pageInfo = new PageInfo<Teacher>(list);
			result.setCode(0);
			result.setData(list);
			result.setCount(pageInfo.getTotal());
			result.setMsg("success!");
		} catch (Exception e) {
			e.printStackTrace();
			result.setCode(1);
			result.setMsg("数据异常！");
		}
		
		return result;
	}
	
}
