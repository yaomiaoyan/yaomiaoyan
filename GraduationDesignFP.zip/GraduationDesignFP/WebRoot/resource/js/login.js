// 点击切换登录角色
$(function(){
	$(".id_icon").click(function(thisobj){
		var target = $(thisobj).attr("target");
		$(target).addClass("sel").siblings().removeClass();
		/*console.log(target);*/
		if($(target).attr("id") == "admin") {
			$("#register").hide();
		} else {
			$("#register").show();
		}
		$("#loginForm")[0].reset();
		//loginutil.refreshCodeImg();
	});
})

// 鼠标悬浮事件
function mouseOver (thisobj){
	$("#loginUsertype").attr("value",$(thisobj).attr("id"));
	if($(thisobj).attr("class") == "sel") {
		thisobj.style.opacity = 1;
	} else {
		thisobj.style.opacity = 0.8;
		
	}
}

// 鼠标移出事件
function mouseOut (thisobj){
	thisobj.style.opacity = 1;
}
