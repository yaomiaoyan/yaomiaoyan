package cn.edu.hbuas.etd.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;

import cn.edu.hbuas.etd.base.BaseController;
import cn.edu.hbuas.etd.po.Admin;
import cn.edu.hbuas.etd.po.College;
import cn.edu.hbuas.etd.po.Major;
import cn.edu.hbuas.etd.po.Student;
import cn.edu.hbuas.etd.po.Teacher;
import cn.edu.hbuas.etd.service.AdminService;
import cn.edu.hbuas.etd.service.CollegeService;
import cn.edu.hbuas.etd.service.MajorService;
import cn.edu.hbuas.etd.service.StudentService;
import cn.edu.hbuas.etd.service.TeacherService;

@Controller
@RequestMapping("/login")
public class LoginController  extends BaseController{
	
	@Autowired
	private TeacherService teacherService;
	
	@Autowired
	private StudentService studentService;
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private MajorService majorService;
	
	@Autowired
	private CollegeService collegeService;
	/**
	 * 跳转登陆
	 * @return
	 */
	@RequestMapping("/login")
	public String login(){
		return "login/login";
	}
	@RequestMapping("/mIndex")
	public String mIndex(){
		return "login/mIndex";
	}
	
	@RequestMapping("/res")
	public String res(){
		return "login/res";
	}
	
	
	
	@RequestMapping("/mtuichu")
	public String mtuichu(HttpServletRequest request){
		//request.getSession().invalidate();
		return "login/login";
	}
	@RequestMapping("/welcome")
	private String welcome(){
		return "login/welcome";
	}
	
	@RequestMapping("/user")
	private String user(HttpServletRequest request, Model model){
		
		Object attribute = request.getSession().getAttribute("userId");
		if (attribute == null){
			return "redirect:/login/login";
		}
		 Student s = new Student();
		 s.setSid(attribute.toString());
		Student byId = studentService.getByEntity(s);
		Major m = new Major();
		m.setMajorId(byId.getSmajorId());
		m.setCollegeId(byId.getScollegeId());
		Major byEntity = majorService.getByEntity(m);
		byId.setMajor(byEntity);
		model.addAttribute("obj", byId);
		return "login/user";
	}
	
	@RequestMapping("/teacher")
	private String teacher(HttpServletRequest request, Model model){
		
		Object attribute = request.getSession().getAttribute("userId");
		if (attribute == null){
			return "redirect:/login/login";
		}
		 Teacher t = new Teacher();
		 t.setTid(attribute.toString());
		 Teacher byEntity = teacherService.getByEntity(t);
		 Major m = new Major();
		 m.setMajorId(byEntity.getTmajorId());
		 m.setCollegeId(byEntity.getTcollegeId());
		 byEntity.setMajor(majorService.getByEntity(m));
		 College c = new College();
		 c.setCollegeId(byEntity.getTcollegeId());
		 College byEntity2 = collegeService.getByEntity(c);
		 byEntity.setCollege(byEntity2);
		 model.addAttribute("obj", byEntity);
		return "login/teacher";
	}
	
	
	@RequestMapping("/toLogin")
	@ResponseBody
	public String toLogin(HttpServletRequest request,String pwd,String name,Integer type){
		 JSONObject j = new  JSONObject();
		 
		 //教师登录
		 if(type == 1){
			 Teacher t = new Teacher();
			 t.setTname(name);
			 t.setTpwd(pwd);
			 List<Teacher> teacher = teacherService.listAllByEntity(t);
			 if (!isEmpty(teacher)){
				    request.getSession().setAttribute("role", type);
					request.getSession().setAttribute("name", teacher.get(0).getTname());
					request.getSession().setAttribute("userId", teacher.get(0).getTid());
					request.getSession().setAttribute("code", teacher.get(0).getTuser());
					j.put("res", 0);
			 }else{
				 j.put("res", 1);
			 }
		 }else if(type == 2){
		  //学生登录
			 Student s = new Student();
			 s.setSname(name);
			 s.setSpwd(pwd);
			 List<Student> student = studentService.listAllByEntity(s);
			 if (!isEmpty(student)){
				    request.getSession().setAttribute("role", type);
					request.getSession().setAttribute("name", student.get(0).getSname());
					request.getSession().setAttribute("userId", student.get(0).getSid());
					request.getSession().setAttribute("code", student.get(0).getSuser());
					j.put("res", 0);
			 }else{
				 j.put("res", 1);
			 }
		 }else if(type == 3){
			  //管理员登录
				 /*Admin a = new Admin();
				 a.setAname(name);
				 a.setApwd(pwd);
				 List<Admin> admin = adminService.listAllByEntity(a);*/
				 if (type == 3){
					    /*request.getSession().setAttribute("role", type);
						request.getSession().setAttribute("name", admin.get(0).getAname());
						request.getSession().setAttribute("userId", admin.get(0).getAid());*/
						/*request.getSession().setAttribute("code", admin.get(0).getAuser());*/
						j.put("res", 2);
				 }else{
					 j.put("res", 1);
				 }
			 }
		 return j.toString();
	}
	/**
	 * 退出
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/tuichu")
	public String tuichu( HttpServletRequest request, HttpServletResponse response){
		HttpSession session = request.getSession();
		session.invalidate();
		return "login/login";
	}
	@RequestMapping("/uTui")
	public String uTui( HttpServletRequest request, HttpServletResponse response){
		HttpSession session = request.getSession();
		session.invalidate();
		return "redirect:/login/uLogin.action";
	}
	

	@RequestMapping("/head")
	private String head(){
		return "inc/head";
	}
	
	@RequestMapping("/left")
	private String left(){
		return "inc/left";
	}
}
