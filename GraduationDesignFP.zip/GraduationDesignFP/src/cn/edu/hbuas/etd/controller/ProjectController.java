package cn.edu.hbuas.etd.controller;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.alibaba.fastjson.JSONObject;

import cn.edu.hbuas.etd.base.BaseController;
import cn.edu.hbuas.etd.po.Project;
import cn.edu.hbuas.etd.service.ProjectService;
import cn.edu.hbuas.etd.utils.Pager;
import cn.edu.hbuas.etd.utils.UUIDUtils;

/**
 * @ClassName:  
 * @Description: 
 * @author  - - admin
 * @date - 2019年05月21日 15时41分13秒
 */


@Controller
@RequestMapping("/project")
public class ProjectController extends BaseController {
	
	
	/**
	 * 依赖注入 start dao/service/===
	 */
	@Autowired
	private ProjectService projectService;
	
	// --------------------------------------- 华丽分割线 ------------------------------
	
	/*********************************查询列表【不分页】***********************************************/
	
	/**
	 * 分页查询 返回list对象(通过对By Sql)
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/findBySql")
	public String findBySql(Project project, Model model, HttpServletRequest request, HttpServletResponse response) {
		//分页查询
		String sql = "SELECT * FROM project WHERE 1=1 ";
        if(!isEmpty(project.getCode())){
        	sql += " and code like '%"+project.getCode()+"%'";
		}
        if(!isEmpty(project.getName())){
        	sql += " and name like '%"+project.getName()+"%'";
		}
        if(!isEmpty(project.getStudentCode())){
        	sql += " and studentCode like '%"+project.getStudentCode()+"%'";
		}
        if(!isEmpty(project.getStudentName())){
        	sql += " and studentName like '%"+project.getStudentName()+"%'";
		}
        if(!isEmpty(project.getMember())){
        	sql += " and member like '%"+project.getMember()+"%'";
		}
        if(!isEmpty(project.getTeacherCode())){
        	sql += " and teacherCode like '%"+project.getTeacherCode()+"%'";
		}
        if(!isEmpty(project.getTeacherName())){
        	sql += " and teacherName like '%"+project.getTeacherName()+"%'";
		}
        if(!isEmpty(project.getStartTime())){
        	sql += " and startTime like '%"+project.getStartTime()+"%'";
		}
        if(!isEmpty(project.getEndTime())){
        	sql += " and endTime like '%"+project.getEndTime()+"%'";
		}
        if(!isEmpty(project.getFunding())){
        	sql += " and funding like '%"+project.getFunding()+"%'";
		}
        if(!isEmpty(project.getOneUrl())){
        	sql += " and oneUrl like '%"+project.getOneUrl()+"%'";
		}
        if(!isEmpty(project.getTwoUrl())){
        	sql += " and twoUrl like '%"+project.getTwoUrl()+"%'";
		}
        if(!isEmpty(project.getThreeUrl())){
        	sql += " and threeUrl like '%"+project.getThreeUrl()+"%'";
		}
        if(!isEmpty(project.getProcess())){
        	sql += " and process like '%"+project.getProcess()+"%'";
		}
        if(!isEmpty(project.getStatus())){
        	sql += " and status like '%"+project.getStatus()+"%'";
		}
        if(!isEmpty(project.getSiDelete())){
        	sql += " and siDelete like '%"+project.getSiDelete()+"%'";
		}
        if(!isEmpty(project.getAddTime())){
        	sql += " and addTime like '%"+project.getAddTime()+"%'";
		}
       sql += " ORDER BY ID DESC ";
		Pager<Project> pagers = projectService.findBySqlRerturnEntity(sql);
		model.addAttribute("pagers", pagers);
		//存储查询条件
		model.addAttribute("obj", project);
		return "project/project";
	}
	
	
	/**
	 * 用户端的项目查看，
	 * @param project
	 * @param model
	 * @param request
	 * @param response
	 * @return
	 */
	//usersqlist
	@RequestMapping(value = "/usersqlist")
	public String usersqlist(Project project, Model model, HttpServletRequest request, HttpServletResponse response) {
		//分页查询
		Object attribute = request.getSession().getAttribute("code");
		if (attribute == null){
			return "redirect:/login/login";
		}
		JSONObject js = new JSONObject();
		Integer code = Integer.valueOf(attribute.toString());
		String sql = "SELECT * FROM project WHERE 1=1 and process = 1 and student_code= "+code;
        if(!isEmpty(project.getCode())){
        	sql += " and code like '%"+project.getCode()+"%'";
		}
        if(!isEmpty(project.getName())){
        	sql += " and name like '%"+project.getName()+"%'";
		}
        if(!isEmpty(project.getStudentCode())){
        	sql += " and student_code like '%"+project.getStudentCode()+"%'";
		}
        if(!isEmpty(project.getStudentName())){
        	sql += " and student_name like '%"+project.getStudentName()+"%'";
		}
        if(!isEmpty(project.getTeacherCode())){
        	sql += " and teacher_code like '%"+project.getTeacherCode()+"%'";
		}
        if(!isEmpty(project.getTeacherName())){
        	sql += " and teacher_name like '%"+project.getTeacherName()+"%'";
		}
       sql += " ORDER BY ID DESC ";
		Pager<Project> pagers = projectService.findBySqlRerturnEntity(sql);
		model.addAttribute("pagers", pagers);
		//存储查询条件
		model.addAttribute("obj", project);
		return "project/usersqlist";
	}
	
	/**
	 * 用户中期文档
	 * @param project
	 * @param model
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/userzqlist")
	public String userzqlist(Project project, Model model, HttpServletRequest request, HttpServletResponse response) {
		//分页查询
		Object attribute = request.getSession().getAttribute("code");
		if (attribute == null){
			return "redirect:/login/login";
		}
		JSONObject js = new JSONObject();
		Integer code = Integer.valueOf(attribute.toString());
		// 
		String sql = "SELECT * FROM project WHERE 1=1 and ((process = 1 and status = 1)or(process = 2)) and student_code= "+code;
        if(!isEmpty(project.getCode())){
        	sql += " and code like '%"+project.getCode()+"%'";
		}
        if(!isEmpty(project.getName())){
        	sql += " and name like '%"+project.getName()+"%'";
		}
        if(!isEmpty(project.getStudentCode())){
        	sql += " and student_code like '%"+project.getStudentCode()+"%'";
		}
        if(!isEmpty(project.getStudentName())){
        	sql += " and student_name like '%"+project.getStudentName()+"%'";
		}
        if(!isEmpty(project.getTeacherCode())){
        	sql += " and teacher_code like '%"+project.getTeacherCode()+"%'";
		}
        if(!isEmpty(project.getTeacherName())){
        	sql += " and teacher_name like '%"+project.getTeacherName()+"%'";
		}
       sql += " ORDER BY ID DESC ";
		Pager<Project> pagers = projectService.findBySqlRerturnEntity(sql);
		model.addAttribute("pagers", pagers);
		//存储查询条件
		model.addAttribute("obj", project);
		return "project/userzqlist";
	}
	
	/**
	 * 用户申请结项
	 * @param project
	 * @param model
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/usersqjxlist")
	public String usersqjxlist(Project project, Model model, HttpServletRequest request, HttpServletResponse response) {
		//分页查询
		Object attribute = request.getSession().getAttribute("code");
		if (attribute == null){
			return "redirect:/login/login";
		}
		JSONObject js = new JSONObject();
		Integer code = Integer.valueOf(attribute.toString());
		// 
		String sql = "SELECT * FROM project WHERE 1=1 and ((process = 3 and status = 0)or(process = 2)) and student_code= "+code;
        if(!isEmpty(project.getCode())){
        	sql += " and code like '%"+project.getCode()+"%'";
		}
        if(!isEmpty(project.getName())){
        	sql += " and name like '%"+project.getName()+"%'";
		}
        if(!isEmpty(project.getStudentCode())){
        	sql += " and student_code like '%"+project.getStudentCode()+"%'";
		}
        if(!isEmpty(project.getStudentName())){
        	sql += " and student_name like '%"+project.getStudentName()+"%'";
		}
        if(!isEmpty(project.getTeacherCode())){
        	sql += " and teacher_code like '%"+project.getTeacherCode()+"%'";
		}
        if(!isEmpty(project.getTeacherName())){
        	sql += " and teacher_name like '%"+project.getTeacherName()+"%'";
		}
       sql += " ORDER BY ID DESC ";
		Pager<Project> pagers = projectService.findBySqlRerturnEntity(sql);
		model.addAttribute("pagers", pagers);
		//存储查询条件
		model.addAttribute("obj", project);
		return "project/usersqjxlist";
	}
	
	
	@RequestMapping(value = "/userjxlist")
	public String userjxlist(Project project, Model model, HttpServletRequest request, HttpServletResponse response) {
		//分页查询
		Object attribute = request.getSession().getAttribute("code");
		if (attribute == null){
			return "redirect:/login/login";
		}
		JSONObject js = new JSONObject();
		Integer code = Integer.valueOf(attribute.toString());
		// 
		String sql = "SELECT * FROM project WHERE 1=1 and process =3 and student_code= "+code;
        if(!isEmpty(project.getCode())){
        	sql += " and code like '%"+project.getCode()+"%'";
		}
        if(!isEmpty(project.getName())){
        	sql += " and name like '%"+project.getName()+"%'";
		}
        if(!isEmpty(project.getStudentCode())){
        	sql += " and student_code like '%"+project.getStudentCode()+"%'";
		}
        if(!isEmpty(project.getStudentName())){
        	sql += " and student_name like '%"+project.getStudentName()+"%'";
		}
        if(!isEmpty(project.getTeacherCode())){
        	sql += " and teacher_code like '%"+project.getTeacherCode()+"%'";
		}
        if(!isEmpty(project.getTeacherName())){
        	sql += " and teacher_name like '%"+project.getTeacherName()+"%'";
		}
       sql += " ORDER BY ID DESC ";
		Pager<Project> pagers = projectService.findBySqlRerturnEntity(sql);
		model.addAttribute("pagers", pagers);
		//存储查询条件
		model.addAttribute("obj", project);
		return "project/userjxlist";
	}
	/**********************************【增删改】******************************************************/
	
	
	//teachersqlist
	/**
	 * 教师端项目申请查看
	 * @param project
	 * @param model
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/teachersqlist")
	public String teachersqlist(Project project, Model model, HttpServletRequest request, HttpServletResponse response) {
		//分页查询
		Object attribute = request.getSession().getAttribute("code");
		if (attribute == null){
			return "redirect:/login/login";
		}
		JSONObject js = new JSONObject();
		Integer code = Integer.valueOf(attribute.toString());
		// 
		String sql = "SELECT * FROM project WHERE 1=1 and process = 1 and status = 0 and teacher_code= "+code;
        if(!isEmpty(project.getCode())){
        	sql += " and code like '%"+project.getCode()+"%'";
		}
        if(!isEmpty(project.getName())){
        	sql += " and name like '%"+project.getName()+"%'";
		}
        if(!isEmpty(project.getStudentCode())){
        	sql += " and student_code like '%"+project.getStudentCode()+"%'";
		}
        if(!isEmpty(project.getStudentName())){
        	sql += " and student_name like '%"+project.getStudentName()+"%'";
		}
        if(!isEmpty(project.getTeacherCode())){
        	sql += " and teacher_code like '%"+project.getTeacherCode()+"%'";
		}
        if(!isEmpty(project.getTeacherName())){
        	sql += " and teacher_name like '%"+project.getTeacherName()+"%'";
		}
       sql += " ORDER BY ID DESC ";
		Pager<Project> pagers = projectService.findBySqlRerturnEntity(sql);
		model.addAttribute("pagers", pagers);
		//存储查询条件
		model.addAttribute("obj", project);
		return "project/teachersqlist";
	}
	
	/**
	 * 教师端，查询中期文档
	 * @param project
	 * @param model
	 * @param request
	 * @param response
	 * @return
	 */
	//teacherzqlist
	@RequestMapping(value = "/teacherzqlist")
	public String teacherzqlist(Project project, Model model, HttpServletRequest request, HttpServletResponse response) {
		//分页查询
		Object attribute = request.getSession().getAttribute("code");
		if (attribute == null){
			return "redirect:/login/login";
		}
		JSONObject js = new JSONObject();
		Integer code = Integer.valueOf(attribute.toString());
		// 
		String sql = "SELECT * FROM project WHERE 1=1 and process = 2 and teacher_code= "+code;
        if(!isEmpty(project.getCode())){
        	sql += " and code like '%"+project.getCode()+"%'";
		}
        if(!isEmpty(project.getName())){
        	sql += " and name like '%"+project.getName()+"%'";
		}
        if(!isEmpty(project.getStudentCode())){
        	sql += " and student_code like '%"+project.getStudentCode()+"%'";
		}
        if(!isEmpty(project.getStudentName())){
        	sql += " and student_name like '%"+project.getStudentName()+"%'";
		}
        if(!isEmpty(project.getTeacherCode())){
        	sql += " and teacher_code like '%"+project.getTeacherCode()+"%'";
		}
        if(!isEmpty(project.getTeacherName())){
        	sql += " and teacher_name like '%"+project.getTeacherName()+"%'";
		}
       sql += " ORDER BY ID DESC ";
		Pager<Project> pagers = projectService.findBySqlRerturnEntity(sql);
		model.addAttribute("pagers", pagers);
		//存储查询条件
		model.addAttribute("obj", project);
		return "project/teacherzqlist";
	}
	
	/**
	 * 教师端
	 * @param project
	 * @param model
	 * @param request
	 * @param response
	 * @return
	 */
	//teachersqjxlist
	@RequestMapping(value = "/teachersqjxlist")
	public String teachersqjxlist(Project project, Model model, HttpServletRequest request, HttpServletResponse response) {
		//分页查询
		Object attribute = request.getSession().getAttribute("code");
		if (attribute == null){
			return "redirect:/login/login";
		}
		JSONObject js = new JSONObject();
		Integer code = Integer.valueOf(attribute.toString());
		// 
		String sql = "SELECT * FROM project WHERE 1=1 and process = 3 and status = 0 and teacher_code= "+code;
        if(!isEmpty(project.getCode())){
        	sql += " and code like '%"+project.getCode()+"%'";
		}
        if(!isEmpty(project.getName())){
        	sql += " and name like '%"+project.getName()+"%'";
		}
        if(!isEmpty(project.getStudentCode())){
        	sql += " and student_code like '%"+project.getStudentCode()+"%'";
		}
        if(!isEmpty(project.getStudentName())){
        	sql += " and student_name like '%"+project.getStudentName()+"%'";
		}
        if(!isEmpty(project.getTeacherCode())){
        	sql += " and teacher_code like '%"+project.getTeacherCode()+"%'";
		}
        if(!isEmpty(project.getTeacherName())){
        	sql += " and teacher_name like '%"+project.getTeacherName()+"%'";
		}
       sql += " ORDER BY ID DESC ";
		Pager<Project> pagers = projectService.findBySqlRerturnEntity(sql);
		model.addAttribute("pagers", pagers);
		//存储查询条件
		model.addAttribute("obj", project);
		return "project/teachersqjxlist";
	}
	
	/**
	 * 教师端查询所有结项的项目
	 * @param project
	 * @param model
	 * @param request
	 * @param response
	 * @return
	 */
	//teacherAll
	@RequestMapping(value = "/teacherAll")
	public String teacherAll(Project project, Model model, HttpServletRequest request, HttpServletResponse response) {
		//分页查询
		Object attribute = request.getSession().getAttribute("code");
		if (attribute == null){
			return "redirect:/login/login";
		}
		JSONObject js = new JSONObject();
		Integer code = Integer.valueOf(attribute.toString());
		// 
		String sql = "SELECT * FROM project WHERE 1=1 and process = 3 and status = 1 ";
        if(!isEmpty(project.getCode())){
        	sql += " and code like '%"+project.getCode()+"%'";
		}
        if(!isEmpty(project.getName())){
        	sql += " and name like '%"+project.getName()+"%'";
		}
        if(!isEmpty(project.getStudentCode())){
        	sql += " and student_code like '%"+project.getStudentCode()+"%'";
		}
        if(!isEmpty(project.getStudentName())){
        	sql += " and student_name like '%"+project.getStudentName()+"%'";
		}
        if(!isEmpty(project.getTeacherCode())){
        	sql += " and teacher_code like '%"+project.getTeacherCode()+"%'";
		}
        if(!isEmpty(project.getTeacherName())){
        	sql += " and teacher_name like '%"+project.getTeacherName()+"%'";
		}
       sql += " ORDER BY ID DESC ";
		Pager<Project> pagers = projectService.findBySqlRerturnEntity(sql);
		model.addAttribute("pagers", pagers);
		//存储查询条件
		model.addAttribute("obj", project);
		return "project/teacherAll";
	}
	/**
	 * 跳至添加页面
	 * @return
	 */
	@RequestMapping(value = "/add")
	public String add() {
		return "project/add";
	}
	
	
	
	/**
	 * 用户申请页面
	 * @return
	 */
	@RequestMapping(value = "/userSq")
	public String userSq() {
		return "project/userSq";
	}

	/**
	 * 跳至详情页面
	 * @return
	 */
	@RequestMapping(value = "/view")
	public String view(Integer id,Model model) {
		Project obj = projectService.load(id);
		model.addAttribute("obj",obj);
		return "project/view";
	}
	
	//lixiangshenpi
	@RequestMapping(value = "/lixiangshenpi")
	public String lixiangshenpi(Integer id,Model model) {
		Project obj = projectService.load(id);
		model.addAttribute("obj",obj);
		return "project/lixiangshenpi";
	}
	
	/**
	 * 结项审批页面
	 * @param id
	 * @param model
	 * @return
	 */
	//jieiangshenpi
	@RequestMapping(value = "/jieiangshenpi")
	public String jieiangshenpi(Integer id,Model model) {
		Project obj = projectService.load(id);
		model.addAttribute("obj",obj);
		return "project/jieiangshenpi";
	}
	
	/**
	 * 教师端立项审批
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/lxsp")
	@ResponseBody
	public String lxsp(Integer id,Integer status,Model model) {
		JSONObject json = new JSONObject();
		Project obj = projectService.load(id);
		obj.setStatus(status);
		model.addAttribute("obj",obj);
		projectService.updateById(obj);
		return json.toJSONString();
	}
	
	/**
	 * 教师端结项审批
	 * @param id
	 * @param status
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/jxsp")
	@ResponseBody
	public String jxsp(Integer id,Integer status,Model model) {
		JSONObject json = new JSONObject();
		Project obj = projectService.load(id);
		obj.setStatus(status);
		model.addAttribute("obj",obj);
		projectService.updateById(obj);
		return json.toJSONString();
	}
	
	//
	
	/**
	 * 跳转至添加中期文档页免
	 * @param id
	 * @param model
	 * @return
	 */
	////addZq
	@RequestMapping(value = "/addZq")
	public String addZq(Integer id,Model model) {
		Project obj = projectService.load(id);
		model.addAttribute("obj",obj);
		return "project/addZq";
	}
	
	/**
	 * 申请结项
	 * @param id
	 * @param model
	 * @return
	 */
	//addJx
	@RequestMapping(value = "/addJx")
	public String addJx(Integer id,Model model) {
		Project obj = projectService.load(id);
		model.addAttribute("obj",obj);
		return "project/addJx";
	}
	/**
	 * 添加执行
	 * @return
	 * @throws IOException 
	 * @throws IllegalStateException 
	 */
	@RequestMapping(value = "/exAdd")
	public String exAdd(@RequestParam(value = "file", required = false) MultipartFile file,Project project, Model model, HttpServletRequest request, HttpServletResponse response) throws IllegalStateException, IOException {
		if (!file.isEmpty()){
			System.out.println("---------------------------------");
			System.out.println(file.getOriginalFilename());
			System.out.println("---------------------------------");
			System.out.println("开始");  
	        long  startTime=System.currentTimeMillis();
	        System.out.println("fileName："+file.getOriginalFilename());
	        String n = UUIDUtils.create();
	        String path="D:/my/upload/"+n+file.getOriginalFilename();
	        System.out.println("===================================================");
	         System.out.println(path);
	        File newFile=new File(path);
	        //通过CommonsMultipartFile的方法直接写文件（注意这个时候）
	        file.transferTo(newFile);
	        long  endTime=System.currentTimeMillis();
	        System.out.println("方法二的运行时间："+String.valueOf(endTime-startTime)+"ms");
	        System.out.println("*********************************************************");
	        System.out.println("*********************************************************");
	        project.setOneUrl("\\upload\\"+n+file.getOriginalFilename());	
		}
		project.setProcess(1);
		project.setStatus(0);
		project.setAddTime(new Date());
		int insert = projectService.insert(project);
		Integer id = project.getId();
		String str=Integer.toString(id);
		while(str.length()<10)
		 {
		  str="0"+str;
		  } 
		project.setCode(str);
		projectService.updateById(project);
		return "redirect:/project/usersqlist.action";
	}
	
	
	
	/**
	 * 添加执行 上传中期文档
	 * @return
	 * @throws IOException 
	 * @throws IllegalStateException 
	 */
	@RequestMapping(value = "/exAddZq")
	public String exAddZq(@RequestParam(value = "file", required = false) MultipartFile file,Project project, Model model, HttpServletRequest request, HttpServletResponse response) throws IllegalStateException, IOException {
		
		Project byId = projectService.getById(project.getId());
		if (!file.isEmpty()){
			System.out.println("---------------------------------");
			System.out.println(file.getOriginalFilename());
			System.out.println("---------------------------------");
			System.out.println("开始");  
	        long  startTime=System.currentTimeMillis();
	        System.out.println("fileName："+file.getOriginalFilename());
	        String n = UUIDUtils.create();
	        String path="D:/my/upload/"+n+file.getOriginalFilename();
	        System.out.println("===================================================");
	         System.out.println(path);
	        File newFile=new File(path);
	        //通过CommonsMultipartFile的方法直接写文件（注意这个时候）
	        file.transferTo(newFile);
	        long  endTime=System.currentTimeMillis();
	        System.out.println("方法二的运行时间："+String.valueOf(endTime-startTime)+"ms");
	        System.out.println("*********************************************************");
	        System.out.println("*********************************************************");
	        byId.setTwoUrl("\\upload\\"+n+file.getOriginalFilename());	
		}
		byId.setProcess(2);
		projectService.updateById(byId);
		return "redirect:/project/userzqlist.action";
	}
	
	/**
	 * 用户提交结项文件
	 * @param file
	 * @param project
	 * @param model
	 * @param request
	 * @param response
	 * @return
	 * @throws IllegalStateException
	 * @throws IOException
	 */
	//exAddJx
	@RequestMapping(value = "/exAddJx")
	public String exAddJx(@RequestParam(value = "file", required = false) MultipartFile file,Project project, Model model, HttpServletRequest request, HttpServletResponse response) throws IllegalStateException, IOException {
		
		Project byId = projectService.getById(project.getId());
		if (!file.isEmpty()){
			System.out.println("---------------------------------");
			System.out.println(file.getOriginalFilename());
			System.out.println("---------------------------------");
			System.out.println("开始");  
	        long  startTime=System.currentTimeMillis();
	        System.out.println("fileName："+file.getOriginalFilename());
	        String n = UUIDUtils.create();
	        String path="D:/my/upload/"+n+file.getOriginalFilename();
	        System.out.println("===================================================");
	         System.out.println(path);
	        File newFile=new File(path);
	        //通过CommonsMultipartFile的方法直接写文件（注意这个时候）
	        file.transferTo(newFile);
	        long  endTime=System.currentTimeMillis();
	        System.out.println("方法二的运行时间："+String.valueOf(endTime-startTime)+"ms");
	        System.out.println("*********************************************************");
	        System.out.println("*********************************************************");
	        byId.setThreeUrl("\\upload\\"+n+file.getOriginalFilename());	
		}
		byId.setProcess(3);
		byId.setStatus(0);
		projectService.updateById(byId);
		return "redirect:/project/usersqjxlist.action";
	}
	
	/**
	 * 跳至修改页面
	 * @return
	 */
	@RequestMapping(value = "/update")
	public String update(Integer id,Model model) {
		Project obj = projectService.load(id);
		model.addAttribute("obj",obj);
		return "project/update";
	}
	
	
	//lxsp
	
	
	/**
	 * 添加修改
	 * @return
	 * @throws IOException 
	 * @throws IllegalStateException 
	 */
	@RequestMapping(value = "/exUpdate")
	public String exUpdate(@RequestParam(value = "file", required = false) MultipartFile file,Project project, Model model, HttpServletRequest request, HttpServletResponse response) throws IllegalStateException, IOException {
		if (!file.isEmpty()){
			System.out.println("---------------------------------");
			System.out.println(file.getOriginalFilename());
			System.out.println("---------------------------------");
			System.out.println("开始");  
	        long  startTime=System.currentTimeMillis();
	        System.out.println("fileName："+file.getOriginalFilename());
	        String n = UUIDUtils.create();
	        String path="D:/my/upload/"+n+file.getOriginalFilename();
	        System.out.println("===================================================");
	         System.out.println(path);
	        File newFile=new File(path);
	        //通过CommonsMultipartFile的方法直接写文件（注意这个时候）
	        file.transferTo(newFile);
	        long  endTime=System.currentTimeMillis();
	        project.setOneUrl("\\upload\\"+n+file.getOriginalFilename());	
		}
		//1.通过实体类修改，可以多传修改条件
		projectService.updateById(project);
		//2.通过主键id修改
		//projectService.updateById(project);
		return "redirect:/project/usersqlist.action";
	}
	
	/**
	 * 删除通过主键
	 * @return
	 */
	@RequestMapping(value = "/delete")
	public String delete(Integer id, Model model, HttpServletRequest request, HttpServletResponse response) {
		///1.通过主键删除
		projectService.deleteById(id);
		return "redirect:/project/usersqlist.action";
	}
	
	// --------------------------------------- 华丽分割线 ------------------------------
	// --------------------------------------- 【下面是ajax操作的方法。】 ------------------------------

	/*********************************查询列表【不分页】***********************************************/
	
	/**
	 * 【不分页 => 查询列表 => 无条件】
	* @Title: listAll 
	* @Description: TODO(这里用一句话描述这个方法的作用) 
	* @param @return 设定文件 
	* @author
	* @return String 返回类型 
	* @throws
	 */
	@RequestMapping(value = "/listAllJson", method = RequestMethod.POST)
	@ResponseBody
	public String listAllJson(Project project, HttpServletRequest request, HttpServletResponse response){
		List<Project> listAll = projectService.listAll();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", listAll);
		jsonObject.put("obj", project);
		return jsonObject.toString();
	}
	
	/**
	 *  【不分页=》查询列表=>有条件】
	* @Title: listByEntity 
	* @Description: TODO(这里用一句话描述这个方法的作用) 
	* @param @return 设定文件 
	* @author
	* @return String 返回类型 
	* @throws
	 */
	@RequestMapping(value = "/listByEntityJson", method = RequestMethod.POST)
	@ResponseBody
	public String listByEntityJson(Project project,  HttpServletRequest request, HttpServletResponse response){
		List<Project> listAll = projectService.listAllByEntity(project);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", listAll);
		jsonObject.put("obj", project);
		return jsonObject.toString();
	}
	
	/**
	 *  【不分页=》查询列表=>有条件】
	* @Title: listByMap 
	* @Description: TODO(这里用一句话描述这个方法的作用) 
	* @param @return 设定文件 
	* @author 
	* @return String 返回类型 
	* @throws
	 */
	@RequestMapping(value = "/listByMapJson", method = RequestMethod.POST)
	@ResponseBody
	public String listByMapJson(Project project,HttpServletRequest request, HttpServletResponse response){
		//通过map查询
		Map<String,Object> params = new HashMap<String,Object>();
	        if(!isEmpty(project.getCode())){
	        	params.put("code", project.getCode());
			}
	        if(!isEmpty(project.getName())){
	        	params.put("name", project.getName());
			}
	        if(!isEmpty(project.getStudentCode())){
	        	params.put("studentCode", project.getStudentCode());
			}
	        if(!isEmpty(project.getStudentName())){
	        	params.put("studentName", project.getStudentName());
			}
	        if(!isEmpty(project.getMember())){
	        	params.put("member", project.getMember());
			}
	        if(!isEmpty(project.getTeacherCode())){
	        	params.put("teacherCode", project.getTeacherCode());
			}
	        if(!isEmpty(project.getTeacherName())){
	        	params.put("teacherName", project.getTeacherName());
			}
	        if(!isEmpty(project.getStartTime())){
	        	params.put("startTime", project.getStartTime());
			}
	        if(!isEmpty(project.getEndTime())){
	        	params.put("endTime", project.getEndTime());
			}
	        if(!isEmpty(project.getFunding())){
	        	params.put("funding", project.getFunding());
			}
	        if(!isEmpty(project.getOneUrl())){
	        	params.put("oneUrl", project.getOneUrl());
			}
	        if(!isEmpty(project.getTwoUrl())){
	        	params.put("twoUrl", project.getTwoUrl());
			}
	        if(!isEmpty(project.getThreeUrl())){
	        	params.put("threeUrl", project.getThreeUrl());
			}
	        if(!isEmpty(project.getProcess())){
	        	params.put("process", project.getProcess());
			}
	        if(!isEmpty(project.getStatus())){
	        	params.put("status", project.getStatus());
			}
	        if(!isEmpty(project.getSiDelete())){
	        	params.put("siDelete", project.getSiDelete());
			}
	        if(!isEmpty(project.getAddTime())){
	        	params.put("addTime", project.getAddTime());
			}
	    List<Project> listAll = projectService.listByMap(params);
	    JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", listAll);
		jsonObject.put("obj", project);
		return jsonObject.toString();
	}
	
	
	/**
	 * 分页查询 返回list json(通过对象)
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/findByObjJson", method = RequestMethod.POST)
	@ResponseBody
	public String findByObjByEntityJson(Project project, HttpServletRequest request, HttpServletResponse response) {
		//分页查询
		Pager<Project> pagers = projectService.findByEntity(project);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("pagers", pagers);
		jsonObject.put("obj", project);
		return jsonObject.toString();
	}
	
	  
	/**
	 * 分页查询 返回list json(通过Map)
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/findByMapJson",  method = RequestMethod.POST)
	@ResponseBody
	public String findByMapJson(Project project,HttpServletRequest request, HttpServletResponse response) {
		//通过map查询
		Map<String,Object> params = new HashMap<String,Object>();
        if(!isEmpty(project.getCode())){
        	params.put("code", project.getCode());
		}
        if(!isEmpty(project.getName())){
        	params.put("name", project.getName());
		}
        if(!isEmpty(project.getStudentCode())){
        	params.put("studentCode", project.getStudentCode());
		}
        if(!isEmpty(project.getStudentName())){
        	params.put("studentName", project.getStudentName());
		}
        if(!isEmpty(project.getMember())){
        	params.put("member", project.getMember());
		}
        if(!isEmpty(project.getTeacherCode())){
        	params.put("teacherCode", project.getTeacherCode());
		}
        if(!isEmpty(project.getTeacherName())){
        	params.put("teacherName", project.getTeacherName());
		}
        if(!isEmpty(project.getStartTime())){
        	params.put("startTime", project.getStartTime());
		}
        if(!isEmpty(project.getEndTime())){
        	params.put("endTime", project.getEndTime());
		}
        if(!isEmpty(project.getFunding())){
        	params.put("funding", project.getFunding());
		}
        if(!isEmpty(project.getOneUrl())){
        	params.put("oneUrl", project.getOneUrl());
		}
        if(!isEmpty(project.getTwoUrl())){
        	params.put("twoUrl", project.getTwoUrl());
		}
        if(!isEmpty(project.getThreeUrl())){
        	params.put("threeUrl", project.getThreeUrl());
		}
        if(!isEmpty(project.getProcess())){
        	params.put("process", project.getProcess());
		}
        if(!isEmpty(project.getStatus())){
        	params.put("status", project.getStatus());
		}
        if(!isEmpty(project.getSiDelete())){
        	params.put("siDelete", project.getSiDelete());
		}
        if(!isEmpty(project.getAddTime())){
        	params.put("addTime", project.getAddTime());
		}
		//分页查询
		Pager<Project> pagers = projectService.findByMap(params);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("pagers", pagers);
		jsonObject.put("obj", project);
		return jsonObject.toString();
	}
	
	
	/**
	 * ajax 添加
	 * @param 
	 * @return
	 */
	@RequestMapping(value = "/exAddJson", method = RequestMethod.POST)
	@ResponseBody
	public String exAddJson(Project project, Model model, HttpServletRequest request, HttpServletResponse response) {
		projectService.insert(project);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("message", "添加成功");
		return jsonObject.toString();
	}
	

	/**
	 * ajax 修改
	 * @param 
	 * @return
	 */
	@RequestMapping(value = "/exUpdate.json", method = RequestMethod.POST)
	@ResponseBody
	public String exUpdateJson(Project project, Model model, HttpServletRequest request, HttpServletResponse response) {
		//1.通过实体类修改，可以多传修改条件
		projectService.updateById(project);
		//2.通过主键id修改
		//projectService.updateById(project);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("message", "修改成功");
		return jsonObject.toString();
	}

	/**
	 * ajax 删除
	 * @return
	 */
	@RequestMapping(value = "/delete.json", method = RequestMethod.POST)
	@ResponseBody
	public String exDeleteJson(Integer id, Model model, HttpServletRequest request, HttpServletResponse response) {
		///1.通过主键删除
		projectService.deleteById(id);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("message", "删除成功");
		return jsonObject.toString();
	}
	/**
	 * 单文件上传
	 * @param file
	 * @param request
	 * @param model
	 * @return
	 */
    @RequestMapping(value = "/saveFile")  
    public String saveFile(@RequestParam(value = "file", required = false) MultipartFile file, HttpServletRequest request, Model model) {  
  
        System.out.println("开始");  
        String path = request.getSession().getServletContext().getRealPath("/upload");  
        String fileName = file.getOriginalFilename();  
        System.out.println(path);  
        File targetFile = new File(path, fileName);  
        if(!targetFile.exists()){  
            targetFile.mkdirs();  
        }  
        //保存  
        try {  
            file.transferTo(targetFile);  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
  
        return "";  
    }  
	
	
	/**
	 * springMvc多文件上传
	 * @param files
	 * @param id
	 * @return
	 */
    @RequestMapping(value = "/saveFiles")
    public String saveFiles(@RequestParam("file") CommonsMultipartFile[] files,Integer id,HttpServletRequest request){
		for(int i = 0;i<files.length;i++){
	      	System.out.println("fileName---------->" + files[i].getOriginalFilename());
		  if(!files[i].isEmpty()){
            int pre = (int) System.currentTimeMillis();
	     	try {
			//拿到输出流，同时重命名上传的文件
			 String filePath = request.getRealPath("/upload");
			 File f=new File(filePath);
			 if(!f.exists()){
				f.mkdirs();
			 }
		     String fileNmae=new Date().getTime() + files[i].getOriginalFilename();
		     File file=new File(filePath+"/"+pre + files[i].getOriginalFilename());
			  if(!file.exists()){
				  file.createNewFile();
			 }
			  files[i].transferTo(file);
		     } catch (Exception e) {
				e.printStackTrace();
				System.out.println("上传出错");
			 }
		  }
		}
	  return "";
	}
 // --------------------------------------- 华丽分割线 ------------------------------
	
	
}
