package cn.edu.hbuas.etd.controller;
import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.alibaba.fastjson.JSONObject;

import cn.edu.hbuas.etd.base.BaseController;
import cn.edu.hbuas.etd.mapper.*;
import cn.edu.hbuas.etd.po.*;
import cn.edu.hbuas.etd.service.*;
import cn.edu.hbuas.etd.utils.Pager;

import java.util.*;

/**
 * @ClassName:  
 * @Description: 
 * @author  - - admin
 * @date - 2019年05月21日 15时41分13秒
 */


@Controller
@RequestMapping("/student")
public class StudentController extends BaseController {
	
	
	/**
	 * 依赖注入 start dao/service/===
	 */
	@Autowired
	private StudentService studentService;
	
	// --------------------------------------- 华丽分割线 ------------------------------
	
	/*********************************查询列表【不分页】***********************************************/
	
	/**
	 * 【不分页 => 查询列表 => 无条件】
	* @Title: listAll 
	* @Description: TODO(这里用一句话描述这个方法的作用) 
	* @param @return 设定文件 
	* @author
	* @return String 返回类型 
	* @throws
	 */
	@RequestMapping(value = "/listAll")
	public String listAll(Student student, Model model, HttpServletRequest request, HttpServletResponse response){
		List<Student> listAll = studentService.listAll();
		model.addAttribute("list", listAll);
		return "student/student";
	}
	
	/**
	 *  【不分页=》查询列表=>有条件】
	* @Title: listByEntity 
	* @Description: TODO(这里用一句话描述这个方法的作用) 
	* @param @return 设定文件 
	* @author
	* @return String 返回类型 
	* @throws
	 */
	@RequestMapping(value = "/listByEntity")
	public String listByEntity(Student student, Model model, HttpServletRequest request, HttpServletResponse response){
		List<Student> listAll = studentService.listAllByEntity(student);
		model.addAttribute("list", listAll);
		return "student/student";
	}
	
	/**
	 *  【不分页=》查询列表=>有条件】
	* @Title: listByMap 
	* @Description: TODO(这里用一句话描述这个方法的作用) 
	* @param @return 设定文件 
	* @author 
	* @return String 返回类型 
	* @throws
	 */
	@RequestMapping(value = "/listByMap")
	public String listByMap(Student student, Model model, HttpServletRequest request, HttpServletResponse response){
		//通过map查询
		Map<String,Object> params = new HashMap<String,Object>();
	        if(!isEmpty(student.getSuser())){
	        	params.put("suser", student.getSuser());
			}
	        if(!isEmpty(student.getSpwd())){
	        	params.put("spwd", student.getSpwd());
			}
	        if(!isEmpty(student.getSname())){
	        	params.put("sname", student.getSname());
			}
	        if(!isEmpty(student.getSgender())){
	        	params.put("sgender", student.getSgender());
			}
	        if(!isEmpty(student.getScollegeId())){
	        	params.put("scollegeId", student.getScollegeId());
			}
	        if(!isEmpty(student.getSmajorId())){
	        	params.put("smajorId", student.getSmajorId());
			}
	        if(!isEmpty(student.getStutorId())){
	        	params.put("stutorId", student.getStutorId());
			}
	        if(!isEmpty(student.getStutorName())){
	        	params.put("stutorName", student.getStutorName());
			}
	        if(!isEmpty(student.getSphone())){
	        	params.put("sphone", student.getSphone());
			}
	        if(!isEmpty(student.getSmail())){
	        	params.put("smail", student.getSmail());
			}
	    List<Student> listAll = studentService.listByMap(params);
		model.addAttribute("list", listAll);
		return "student/student";
	}
	
	
	/*********************************查询列表【分页】***********************************************/
	
	
	
	/**
	 * 分页查询 返回list对象(通过对象)
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/findByObj")
	public String findByObj(Student student, Model model, HttpServletRequest request, HttpServletResponse response) {
		//分页查询
		Pager<Student> pagers = studentService.findByEntity(student);
		model.addAttribute("pagers", pagers);
		//存储查询条件
		model.addAttribute("obj", student);
		return "student/student";
	}
	
	/**
	 * 分页查询 返回list对象(通过对By Sql)
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/findBySql")
	public String findBySql(Student student, Model model, HttpServletRequest request, HttpServletResponse response) {
		//分页查询
		String sql = "SELECT * FROM student WHERE 1=1 ";
        if(!isEmpty(student.getSuser())){
        	sql += " and suser like '%"+student.getSuser()+"%'";
		}
        if(!isEmpty(student.getSpwd())){
        	sql += " and spwd like '%"+student.getSpwd()+"%'";
		}
        if(!isEmpty(student.getSname())){
        	sql += " and sname like '%"+student.getSname()+"%'";
		}
        if(!isEmpty(student.getSgender())){
        	sql += " and sgender like '%"+student.getSgender()+"%'";
		}
        if(!isEmpty(student.getScollegeId())){
        	sql += " and scollegeId like '%"+student.getScollegeId()+"%'";
		}
        if(!isEmpty(student.getSmajorId())){
        	sql += " and smajorId like '%"+student.getSmajorId()+"%'";
		}
        if(!isEmpty(student.getStutorId())){
        	sql += " and stutorId like '%"+student.getStutorId()+"%'";
		}
        if(!isEmpty(student.getStutorName())){
        	sql += " and stutorName like '%"+student.getStutorName()+"%'";
		}
        if(!isEmpty(student.getSphone())){
        	sql += " and sphone like '%"+student.getSphone()+"%'";
		}
        if(!isEmpty(student.getSmail())){
        	sql += " and smail like '%"+student.getSmail()+"%'";
		}
       sql += " ORDER BY ID DESC ";
		Pager<Student> pagers = studentService.findBySqlRerturnEntity(sql);
		model.addAttribute("pagers", pagers);
		//存储查询条件
		model.addAttribute("obj", student);
		return "student/student";
	}
	
	
	/**
	 * 分页查询 返回list对象(通过Map)
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/findByMap")
	public String findByMap(Student student, Model model, HttpServletRequest request, HttpServletResponse response) {
		//通过map查询
		Map<String,Object> params = new HashMap<String,Object>();
        if(!isEmpty(student.getSuser())){
        	params.put("suser", student.getSuser());
		}
        if(!isEmpty(student.getSpwd())){
        	params.put("spwd", student.getSpwd());
		}
        if(!isEmpty(student.getSname())){
        	params.put("sname", student.getSname());
		}
        if(!isEmpty(student.getSgender())){
        	params.put("sgender", student.getSgender());
		}
        if(!isEmpty(student.getScollegeId())){
        	params.put("scollegeId", student.getScollegeId());
		}
        if(!isEmpty(student.getSmajorId())){
        	params.put("smajorId", student.getSmajorId());
		}
        if(!isEmpty(student.getStutorId())){
        	params.put("stutorId", student.getStutorId());
		}
        if(!isEmpty(student.getStutorName())){
        	params.put("stutorName", student.getStutorName());
		}
        if(!isEmpty(student.getSphone())){
        	params.put("sphone", student.getSphone());
		}
        if(!isEmpty(student.getSmail())){
        	params.put("smail", student.getSmail());
		}
		//分页查询
		Pager<Student> pagers = studentService.findByMap(params);
		model.addAttribute("pagers", pagers);
		//存储查询条件
		model.addAttribute("obj", student);
		return "student/student";
	}
	
	/**********************************【增删改】******************************************************/
	
	/**
	 * 跳至添加页面
	 * @return
	 */
	@RequestMapping(value = "/add")
	public String add() {
		return "student/add";
	}

	/**
	 * 跳至详情页面
	 * @return
	 */
	@RequestMapping(value = "/view")
	public String view(Integer id,Model model) {
		Student obj = studentService.load(id);
		model.addAttribute("obj",obj);
		return "student/view";
	}
	
	/**
	 * 添加执行
	 * @return
	 */
	@RequestMapping(value = "/exAdd")
	public String exAdd(Student student, Model model, HttpServletRequest request, HttpServletResponse response) {
		studentService.insert(student);
		return "redirect:/student/findBySql.action";
	}
	
	
	/**
	 * 跳至修改页面
	 * @return
	 */
	@RequestMapping(value = "/update")
	public String update(Integer id,Model model) {
		Student obj = studentService.load(id);
		model.addAttribute("obj",obj);
		return "student/update";
	}
	
	/**
	 * 添加修改
	 * @return
	 */
	@RequestMapping(value = "/exUpdate")
	public String exUpdate(Student student, Model model, HttpServletRequest request, HttpServletResponse response) {
		//1.通过实体类修改，可以多传修改条件
		studentService.updateById(student);
		//2.通过主键id修改
		//studentService.updateById(student);
		return "redirect:/student/findBySql.action";
	}
	
	/**
	 * 删除通过主键
	 * @return
	 */
	@RequestMapping(value = "/delete")
	public String delete(Integer id, Model model, HttpServletRequest request, HttpServletResponse response) {
		///1.通过主键删除
		studentService.deleteById(id);
		return "redirect:/student/findBySql.action";
	}
	
	// --------------------------------------- 华丽分割线 ------------------------------
	// --------------------------------------- 【下面是ajax操作的方法。】 ------------------------------

	/*********************************查询列表【不分页】***********************************************/
	
	/**
	 * 【不分页 => 查询列表 => 无条件】
	* @Title: listAll 
	* @Description: TODO(这里用一句话描述这个方法的作用) 
	* @param @return 设定文件 
	* @author
	* @return String 返回类型 
	* @throws
	 */
	@RequestMapping(value = "/listAllJson", method = RequestMethod.POST)
	@ResponseBody
	public String listAllJson(Student student, HttpServletRequest request, HttpServletResponse response){
		List<Student> listAll = studentService.listAll();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", listAll);
		jsonObject.put("obj", student);
		return jsonObject.toString();
	}
	
	/**
	 *  【不分页=》查询列表=>有条件】
	* @Title: listByEntity 
	* @Description: TODO(这里用一句话描述这个方法的作用) 
	* @param @return 设定文件 
	* @author
	* @return String 返回类型 
	* @throws
	 */
	@RequestMapping(value = "/listByEntityJson", method = RequestMethod.POST)
	@ResponseBody
	public String listByEntityJson(Student student,  HttpServletRequest request, HttpServletResponse response){
		List<Student> listAll = studentService.listAllByEntity(student);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", listAll);
		jsonObject.put("obj", student);
		return jsonObject.toString();
	}
	
	/**
	 *  【不分页=》查询列表=>有条件】
	* @Title: listByMap 
	* @Description: TODO(这里用一句话描述这个方法的作用) 
	* @param @return 设定文件 
	* @author 
	* @return String 返回类型 
	* @throws
	 */
	@RequestMapping(value = "/listByMapJson", method = RequestMethod.POST)
	@ResponseBody
	public String listByMapJson(Student student,HttpServletRequest request, HttpServletResponse response){
		//通过map查询
		Map<String,Object> params = new HashMap<String,Object>();
	        if(!isEmpty(student.getSuser())){
	        	params.put("suser", student.getSuser());
			}
	        if(!isEmpty(student.getSpwd())){
	        	params.put("spwd", student.getSpwd());
			}
	        if(!isEmpty(student.getSname())){
	        	params.put("sname", student.getSname());
			}
	        if(!isEmpty(student.getSgender())){
	        	params.put("sgender", student.getSgender());
			}
	        if(!isEmpty(student.getScollegeId())){
	        	params.put("scollegeId", student.getScollegeId());
			}
	        if(!isEmpty(student.getSmajorId())){
	        	params.put("smajorId", student.getSmajorId());
			}
	        if(!isEmpty(student.getStutorId())){
	        	params.put("stutorId", student.getStutorId());
			}
	        if(!isEmpty(student.getStutorName())){
	        	params.put("stutorName", student.getStutorName());
			}
	        if(!isEmpty(student.getSphone())){
	        	params.put("sphone", student.getSphone());
			}
	        if(!isEmpty(student.getSmail())){
	        	params.put("smail", student.getSmail());
			}
	    List<Student> listAll = studentService.listByMap(params);
	    JSONObject jsonObject = new JSONObject();
		jsonObject.put("list", listAll);
		jsonObject.put("obj", student);
		return jsonObject.toString();
	}
	
	
	/**
	 * 分页查询 返回list json(通过对象)
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/findByObjJson", method = RequestMethod.POST)
	@ResponseBody
	public String findByObjByEntityJson(Student student, HttpServletRequest request, HttpServletResponse response) {
		//分页查询
		Pager<Student> pagers = studentService.findByEntity(student);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("pagers", pagers);
		jsonObject.put("obj", student);
		return jsonObject.toString();
	}
	
	  
	/**
	 * 分页查询 返回list json(通过Map)
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/findByMapJson",  method = RequestMethod.POST)
	@ResponseBody
	public String findByMapJson(Student student,HttpServletRequest request, HttpServletResponse response) {
		//通过map查询
		Map<String,Object> params = new HashMap<String,Object>();
        if(!isEmpty(student.getSuser())){
        	params.put("suser", student.getSuser());
		}
        if(!isEmpty(student.getSpwd())){
        	params.put("spwd", student.getSpwd());
		}
        if(!isEmpty(student.getSname())){
        	params.put("sname", student.getSname());
		}
        if(!isEmpty(student.getSgender())){
        	params.put("sgender", student.getSgender());
		}
        if(!isEmpty(student.getScollegeId())){
        	params.put("scollegeId", student.getScollegeId());
		}
        if(!isEmpty(student.getSmajorId())){
        	params.put("smajorId", student.getSmajorId());
		}
        if(!isEmpty(student.getStutorId())){
        	params.put("stutorId", student.getStutorId());
		}
        if(!isEmpty(student.getStutorName())){
        	params.put("stutorName", student.getStutorName());
		}
        if(!isEmpty(student.getSphone())){
        	params.put("sphone", student.getSphone());
		}
        if(!isEmpty(student.getSmail())){
        	params.put("smail", student.getSmail());
		}
		//分页查询
		Pager<Student> pagers = studentService.findByMap(params);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("pagers", pagers);
		jsonObject.put("obj", student);
		return jsonObject.toString();
	}
	
	
	/**
	 * ajax 添加
	 * @param 
	 * @return
	 */
	@RequestMapping(value = "/exAddJson", method = RequestMethod.POST)
	@ResponseBody
	public String exAddJson(Student student, Model model, HttpServletRequest request, HttpServletResponse response) {
		studentService.insert(student);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("message", "添加成功");
		return jsonObject.toString();
	}
	

	/**
	 * ajax 修改
	 * @param 
	 * @return
	 */
	@RequestMapping(value = "/exUpdate.json", method = RequestMethod.POST)
	@ResponseBody
	public String exUpdateJson(Student student, Model model, HttpServletRequest request, HttpServletResponse response) {
		//1.通过实体类修改，可以多传修改条件
		studentService.updateById(student);
		//2.通过主键id修改
		//studentService.updateById(student);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("message", "修改成功");
		return jsonObject.toString();
	}

	/**
	 * ajax 删除
	 * @return
	 */
	@RequestMapping(value = "/delete.json", method = RequestMethod.POST)
	@ResponseBody
	public String exDeleteJson(Integer id, Model model, HttpServletRequest request, HttpServletResponse response) {
		///1.通过主键删除
		studentService.deleteById(id);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("message", "删除成功");
		return jsonObject.toString();
	}
	/**
	 * 单文件上传
	 * @param file
	 * @param request
	 * @param model
	 * @return
	 */
    @RequestMapping(value = "/saveFile")  
    public String saveFile(@RequestParam(value = "file", required = false) MultipartFile file, HttpServletRequest request, Model model) {  
  
        System.out.println("开始");  
        String path = request.getSession().getServletContext().getRealPath("/upload");  
        String fileName = file.getOriginalFilename();  
        System.out.println(path);  
        File targetFile = new File(path, fileName);  
        if(!targetFile.exists()){  
            targetFile.mkdirs();  
        }  
        //保存  
        try {  
            file.transferTo(targetFile);  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
  
        return "";  
    }  
	
	
	/**
	 * springMvc多文件上传
	 * @param files
	 * @param id
	 * @return
	 */
    @RequestMapping(value = "/saveFiles")
    public String saveFiles(@RequestParam("file") CommonsMultipartFile[] files,Integer id,HttpServletRequest request){
		for(int i = 0;i<files.length;i++){
	      	System.out.println("fileName---------->" + files[i].getOriginalFilename());
		  if(!files[i].isEmpty()){
            int pre = (int) System.currentTimeMillis();
	     	try {
			//拿到输出流，同时重命名上传的文件
			 String filePath = request.getRealPath("/upload");
			 File f=new File(filePath);
			 if(!f.exists()){
				f.mkdirs();
			 }
		     String fileNmae=new Date().getTime() + files[i].getOriginalFilename();
		     File file=new File(filePath+"/"+pre + files[i].getOriginalFilename());
			  if(!file.exists()){
				  file.createNewFile();
			 }
			  files[i].transferTo(file);
		     } catch (Exception e) {
				e.printStackTrace();
				System.out.println("上传出错");
			 }
		  }
		}
	  return "";
	}
 // --------------------------------------- 华丽分割线 ------------------------------
	
	
}
