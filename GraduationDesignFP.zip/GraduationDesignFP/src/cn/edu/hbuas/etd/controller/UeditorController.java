package cn.edu.hbuas.etd.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import cn.edu.hbuas.etd.po.Project;
import cn.edu.hbuas.etd.service.ProjectService;
import cn.edu.hbuas.etd.utils.UUIDUtils;

@Controller
@RequestMapping("/ueditor")
public class UeditorController {
	
	@Autowired
	private ProjectService projectService;
	
	  
	  @ResponseBody  
	@RequestMapping(value = "/saveFile")  
    public Map<String, Object> saveFile(@RequestParam(value = "upfile", required = false) MultipartFile file,HttpServletRequest request, Model model) throws IllegalStateException, IOException {  
		  Map<String, Object> params = new HashMap<String, Object>();  
    	  System.out.println("开始");  
          long  startTime=System.currentTimeMillis();
          System.out.println("fileName："+file.getOriginalFilename());
          String n = UUIDUtils.create();
          String path="D:/my/ueditor/"+n+file.getOriginalFilename();
          System.out.println("===================================================");
           System.out.println(path);
          File newFile=new File(path);
          //通过CommonsMultipartFile的方法直接写文件（注意这个时候）
          file.transferTo(newFile);
          String visitUrl = "/ueditor/"; 
          visitUrl = visitUrl.concat(n+file.getOriginalFilename());
          long  endTime=System.currentTimeMillis();
          System.out.println("方法二的运行时间："+String.valueOf(endTime-startTime)+"ms");
         System.out.println("*********************************************************");
         System.out.println("*********************************************************");
         params.put("state", "SUCCESS");  
         params.put("url", visitUrl);  
         params.put("size", file.getSize());  
         params.put("original", file.getOriginalFilename());  
         params.put("type", file.getContentType());  
         return params;  
    }  
	  
	  
	  @RequestMapping(value="/download",method=RequestMethod.GET) 
	    public ResponseEntity<byte[]> download(Integer id,Integer type,HttpServletRequest request ,
	            Model model) throws IOException{
	        
	    	Project byId = projectService.getById(id);
	        String downloadFilePath="D:/my";//从我们的上传文件夹中去取
	        String filename = null;
	        if (type == 1){
	        	filename = byId.getOneUrl();
	        }
	        if (type == 2){
	        	filename = byId.getTwoUrl();
	        }
	        if (type == 3){
	        	filename = byId.getThreeUrl();
	        }
	        File file = new File(downloadFilePath+File.separator+filename);//新建一个文件
	        
	        HttpHeaders headers = new HttpHeaders();//http头信息
	        
	        String downloadFileName = new String(filename.getBytes("UTF-8"),"iso-8859-1");//设置编码
	        
	        headers.setContentDispositionFormData("attachment", downloadFileName);
	        
	        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
	        
	        return new ResponseEntity<byte[]>(FileUtils.readFileToByteArray(file),headers,HttpStatus.CREATED);
	        
	    }
    
}
