package cn.edu.hbuas.etd.mapper;
import cn.edu.hbuas.etd.base.BaseDao;
import cn.edu.hbuas.etd.po.Admin;

/**
 * @ClassName:  
 * @Description: 
 * @author  - - admin
 * @date - 2019年05月21日 15时41分10秒
 */


public interface AdminMapper extends BaseDao<Admin>{
	
}
