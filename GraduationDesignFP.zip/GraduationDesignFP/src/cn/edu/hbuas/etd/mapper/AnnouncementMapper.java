package cn.edu.hbuas.etd.mapper;
import cn.edu.hbuas.etd.base.BaseDao;
import cn.edu.hbuas.etd.po.Announcement;

/**
 * @ClassName:  
 * @Description: 
 * @author  - - admin
 * @date - 2019年05月21日 15时41分12秒
 */


public interface AnnouncementMapper extends BaseDao<Announcement>{
	
}
