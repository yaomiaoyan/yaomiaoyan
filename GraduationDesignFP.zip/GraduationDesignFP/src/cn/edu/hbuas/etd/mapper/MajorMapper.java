package cn.edu.hbuas.etd.mapper;
import cn.edu.hbuas.etd.base.BaseDao;
import cn.edu.hbuas.etd.po.Major;

/**
 * @ClassName:  
 * @Description: 
 * @author  - - admin
 * @date - 2019年05月21日 15时41分13秒
 */


public interface MajorMapper extends BaseDao<Major>{
	
}
