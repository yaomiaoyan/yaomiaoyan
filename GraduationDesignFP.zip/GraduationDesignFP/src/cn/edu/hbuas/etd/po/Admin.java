package cn.edu.hbuas.etd.po;
import java.util.*;
import java.io.Serializable;

/**
 * @ClassName:  
 * @Description: 
 * @author administrator
 * @date - 2019年05月21日 15时41分10秒
 */
public class Admin implements Serializable {
    private static final long serialVersionUID = 3148176768559230877L;
    

	/** 
	 *  @Fields Aid : aid
	 * 
	 * */
	private String aid;
	/** 
	 *  @Fields Auser : auser
	 * 
	 * */
	private String auser;
	/** 
	 *  @Fields Apwd : apwd
	 * 
	 * */
	private String apwd;
	/** 
	 *  @Fields Aname : aname
	 * 
	 * */
	private String aname;

	public String getAid() {
		return this.aid;
	}
	
	public void setAid(String aid) {
		this.aid = aid;
	}
	
	public String getAuser() {
		return this.auser;
	}
	
	public void setAuser(String auser) {
		this.auser = auser;
	}
	
	public String getApwd() {
		return this.apwd;
	}
	
	public void setApwd(String apwd) {
		this.apwd = apwd;
	}
	
	public String getAname() {
		return this.aname;
	}
	
	public void setAname(String aname) {
		this.aname = aname;
	}
	
	
    public Admin() {
		
	}

	public Admin(String aid ,String auser ,String apwd ,String aname ){
	super();
	this.aid=aid;
	this.auser=auser;
	this.apwd=apwd;
	this.aname=aname;
	}
	
	@Override
	public String toString() {
		return "Admin [aid="+ aid + ",auser="+ auser + ",apwd="+ apwd + ",aname="+ aname +  "]";
	}


}

