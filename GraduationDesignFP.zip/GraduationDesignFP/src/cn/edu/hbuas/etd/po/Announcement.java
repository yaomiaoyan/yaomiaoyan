package cn.edu.hbuas.etd.po;
import java.util.*;
import java.io.Serializable;

/**
 * @ClassName:  
 * @Description: 
 * @author administrator
 * @date - 2019年05月21日 15时41分12秒
 */
public class Announcement implements Serializable {
    private static final long serialVersionUID = 3148176768559230877L;
    

	/** 
	 *  @Fields Id : id
	 * 
	 * */
	private String id;
	/** 
	 *  @Fields AdminId : adminId
	 * 
	 * */
	private Integer adminId;
	/** 
	 *  @Fields AdminName : adminName
	 * 
	 * */
	private String adminName;
	/** 
	 *  @Fields Title : title
	 * 
	 * */
	private String title;
	/** 
	 *  @Fields Content : content
	 * 
	 * */
	private String content;

	public String getId() {
		return this.id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public Integer getAdminId() {
		return this.adminId;
	}
	
	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}
	
	public String getAdminName() {
		return this.adminName;
	}
	
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	
	public String getTitle() {
		return this.title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getContent() {
		return this.content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}
	
	
    public Announcement() {
		
	}

	public Announcement(String id ,Integer adminId ,String adminName ,String title ,String content ){
	super();
	this.id=id;
	this.adminId=adminId;
	this.adminName=adminName;
	this.title=title;
	this.content=content;
	}
	
	@Override
	public String toString() {
		return "Announcement [id="+ id + ",adminId="+ adminId + ",adminName="+ adminName + ",title="+ title + ",content="+ content +  "]";
	}


}

