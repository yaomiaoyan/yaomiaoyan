package cn.edu.hbuas.etd.po;
import java.util.*;
import java.io.Serializable;

/**
 * @ClassName:  
 * @Description: 
 * @author administrator
 * @date - 2019年05月21日 15时41分13秒
 */
public class College implements Serializable {
    private static final long serialVersionUID = 3148176768559230877L;
    

	/** 
	 *  @Fields CollegeId : collegeId
	 * 
	 * */
	private Integer collegeId;
	/** 
	 *  @Fields College : college
	 * 
	 * */
	private String college;

	public Integer getCollegeId() {
		return this.collegeId;
	}
	
	public void setCollegeId(Integer collegeId) {
		this.collegeId = collegeId;
	}
	
	public String getCollege() {
		return this.college;
	}
	
	public void setCollege(String college) {
		this.college = college;
	}
	
	
    public College() {
		
	}

	public College(Integer collegeId ,String college ){
	super();
	this.collegeId=collegeId;
	this.college=college;
	}
	
	@Override
	public String toString() {
		return "College [collegeId="+ collegeId + ",college="+ college +  "]";
	}


}

