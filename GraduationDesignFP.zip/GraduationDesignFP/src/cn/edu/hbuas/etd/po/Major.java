package cn.edu.hbuas.etd.po;
import java.util.*;
import java.io.Serializable;

/**
 * @ClassName:  
 * @Description: 
 * @author administrator
 * @date - 2019年05月21日 15时41分13秒
 */
public class Major implements Serializable {
    private static final long serialVersionUID = 3148176768559230877L;
    

	/** 
	 *  @Fields CollegeId : collegeId
	 * 
	 * */
	private Integer collegeId;
	/** 
	 *  @Fields MajorId : majorId
	 * 
	 * */
	private Integer majorId;
	/** 
	 *  @Fields Major : major
	 * 
	 * */
	private String major;

	public Integer getCollegeId() {
		return this.collegeId;
	}
	
	public void setCollegeId(Integer collegeId) {
		this.collegeId = collegeId;
	}
	
	public Integer getMajorId() {
		return this.majorId;
	}
	
	public void setMajorId(Integer majorId) {
		this.majorId = majorId;
	}
	
	public String getMajor() {
		return this.major;
	}
	
	public void setMajor(String major) {
		this.major = major;
	}
	
	
    public Major() {
		
	}

	public Major(Integer collegeId ,Integer majorId ,String major ){
	super();
	this.collegeId=collegeId;
	this.majorId=majorId;
	this.major=major;
	}
	
	@Override
	public String toString() {
		return "Major [collegeId="+ collegeId + ",majorId="+ majorId + ",major="+ major +  "]";
	}


}

