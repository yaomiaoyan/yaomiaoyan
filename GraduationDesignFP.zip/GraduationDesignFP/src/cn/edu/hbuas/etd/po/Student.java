package cn.edu.hbuas.etd.po;
import java.util.*;
import java.io.Serializable;

/**
 * @ClassName:  
 * @Description: 
 * @author administrator
 * @date - 2019年05月21日 15时41分13秒
 */
public class Student implements Serializable {
    private static final long serialVersionUID = 3148176768559230877L;
    

	/** 
	 *  @Fields Sid : sid
	 * 
	 * */
	private String sid;
	/** 
	 *  @Fields Suser : suser
	 * 
	 * */
	private Integer suser;
	/** 
	 *  @Fields Spwd : spwd
	 * 
	 * */
	private String spwd;
	/** 
	 *  @Fields Sname : sname
	 * 
	 * */
	private String sname;
	/** 
	 *  @Fields Sgender : sgender
	 * 
	 * */
	private String sgender;
	/** 
	 *  @Fields ScollegeId : scollegeId
	 * 
	 * */
	private Integer scollegeId;
	
	private College college;
	
	private Major major;
	/** 
	 *  @Fields SmajorId : smajorId
	 * 
	 * */
	private Integer smajorId;
	/** 
	 *  @Fields StutorId : stutorId
	 * 
	 * */
	private Integer stutorId;
	/** 
	 *  @Fields StutorName : stutorName
	 * 
	 * */
	private String stutorName;
	/** 
	 *  @Fields Sphone : sphone
	 * 
	 * */
	private java.lang.Long sphone;
	/** 
	 *  @Fields Smail : smail
	 * 
	 * */
	private String smail;

	public String getSid() {
		return this.sid;
	}
	
	public void setSid(String sid) {
		this.sid = sid;
	}
	
	public Integer getSuser() {
		return this.suser;
	}
	
	public void setSuser(Integer suser) {
		this.suser = suser;
	}
	
	public String getSpwd() {
		return this.spwd;
	}
	
	public void setSpwd(String spwd) {
		this.spwd = spwd;
	}
	
	public String getSname() {
		return this.sname;
	}
	
	public void setSname(String sname) {
		this.sname = sname;
	}
	
	public String getSgender() {
		return this.sgender;
	}
	
	public void setSgender(String sgender) {
		this.sgender = sgender;
	}
	
	public Integer getScollegeId() {
		return this.scollegeId;
	}
	
	public void setScollegeId(Integer scollegeId) {
		this.scollegeId = scollegeId;
	}
	
	public Integer getSmajorId() {
		return this.smajorId;
	}
	
	public void setSmajorId(Integer smajorId) {
		this.smajorId = smajorId;
	}
	
	public Integer getStutorId() {
		return this.stutorId;
	}
	
	public void setStutorId(Integer stutorId) {
		this.stutorId = stutorId;
	}
	
	public String getStutorName() {
		return this.stutorName;
	}
	
	public void setStutorName(String stutorName) {
		this.stutorName = stutorName;
	}
	
	public java.lang.Long getSphone() {
		return this.sphone;
	}
	
	public void setSphone(java.lang.Long sphone) {
		this.sphone = sphone;
	}
	
	public String getSmail() {
		return this.smail;
	}
	
	public void setSmail(String smail) {
		this.smail = smail;
	}
	
	
    public Student() {
		
	}

	public Student(String sid ,Integer suser ,String spwd ,String sname ,String sgender ,Integer scollegeId ,Integer smajorId ,Integer stutorId ,String stutorName ,java.lang.Long sphone ,String smail ){
	super();
	this.sid=sid;
	this.suser=suser;
	this.spwd=spwd;
	this.sname=sname;
	this.sgender=sgender;
	this.scollegeId=scollegeId;
	this.smajorId=smajorId;
	this.stutorId=stutorId;
	this.stutorName=stutorName;
	this.sphone=sphone;
	this.smail=smail;
	}
	
	@Override
	public String toString() {
		return "Student [sid="+ sid + ",suser="+ suser + ",spwd="+ spwd + ",sname="+ sname + ",sgender="+ sgender + ",scollegeId="+ scollegeId + ",smajorId="+ smajorId + ",stutorId="+ stutorId + ",stutorName="+ stutorName + ",sphone="+ sphone + ",smail="+ smail +  "]";
	}

	public College getCollege() {
		return college;
	}

	public void setCollege(College college) {
		this.college = college;
	}

	public Major getMajor() {
		return major;
	}

	public void setMajor(Major major) {
		this.major = major;
	}


}

