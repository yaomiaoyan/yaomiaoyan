package cn.edu.hbuas.etd.po;
import java.util.*;
import java.io.Serializable;

/**
 * @ClassName:  
 * @Description: 
 * @author administrator
 * @date - 2019年05月21日 15时41分13秒
 */
public class Teacher implements Serializable {
    private static final long serialVersionUID = 3148176768559230877L;
    

	/** 
	 *  @Fields Tid : tid
	 * 
	 * */
	private String tid;
	/** 
	 *  @Fields Tuser : tuser
	 * 
	 * */
	private Integer tuser;
	/** 
	 *  @Fields Tpwd : tpwd
	 * 
	 * */
	private String tpwd;
	/** 
	 *  @Fields Tname : tname
	 * 
	 * */
	private String tname;
	/** 
	 *  @Fields Tgender : tgender
	 * 
	 * */
	private String tgender;
	/** 
	 *  @Fields TcollegeId : tcollegeId
	 * 
	 * */
	private Integer tcollegeId;
	/** 
	 *  @Fields TmajorId : tmajorId
	 * 
	 * */
	private Integer tmajorId;
	/** 
	 *  @Fields Tphone : tphone
	 * 
	 * */
	private java.lang.Long tphone;
	/** 
	 *  @Fields Tmail : tmail
	 * 
	 * */
	
   private College college;
	
	private Major major;
	
	
	public College getCollege() {
		return college;
	}

	public void setCollege(College college) {
		this.college = college;
	}

	public Major getMajor() {
		return major;
	}

	public void setMajor(Major major) {
		this.major = major;
	}

	private String tmail;

	public String getTid() {
		return this.tid;
	}
	
	public void setTid(String tid) {
		this.tid = tid;
	}
	
	public Integer getTuser() {
		return this.tuser;
	}
	
	public void setTuser(Integer tuser) {
		this.tuser = tuser;
	}
	
	public String getTpwd() {
		return this.tpwd;
	}
	
	public void setTpwd(String tpwd) {
		this.tpwd = tpwd;
	}
	
	public String getTname() {
		return this.tname;
	}
	
	public void setTname(String tname) {
		this.tname = tname;
	}
	
	public String getTgender() {
		return this.tgender;
	}
	
	public void setTgender(String tgender) {
		this.tgender = tgender;
	}
	
	public Integer getTcollegeId() {
		return this.tcollegeId;
	}
	
	public void setTcollegeId(Integer tcollegeId) {
		this.tcollegeId = tcollegeId;
	}
	
	public Integer getTmajorId() {
		return this.tmajorId;
	}
	
	public void setTmajorId(Integer tmajorId) {
		this.tmajorId = tmajorId;
	}
	
	public java.lang.Long getTphone() {
		return this.tphone;
	}
	
	public void setTphone(java.lang.Long tphone) {
		this.tphone = tphone;
	}
	
	public String getTmail() {
		return this.tmail;
	}
	
	public void setTmail(String tmail) {
		this.tmail = tmail;
	}
	
	
    public Teacher() {
		
	}

	public Teacher(String tid ,Integer tuser ,String tpwd ,String tname ,String tgender ,Integer tcollegeId ,Integer tmajorId ,java.lang.Long tphone ,String tmail ){
	super();
	this.tid=tid;
	this.tuser=tuser;
	this.tpwd=tpwd;
	this.tname=tname;
	this.tgender=tgender;
	this.tcollegeId=tcollegeId;
	this.tmajorId=tmajorId;
	this.tphone=tphone;
	this.tmail=tmail;
	}
	
	@Override
	public String toString() {
		return "Teacher [tid="+ tid + ",tuser="+ tuser + ",tpwd="+ tpwd + ",tname="+ tname + ",tgender="+ tgender + ",tcollegeId="+ tcollegeId + ",tmajorId="+ tmajorId + ",tphone="+ tphone + ",tmail="+ tmail +  "]";
	}


}

