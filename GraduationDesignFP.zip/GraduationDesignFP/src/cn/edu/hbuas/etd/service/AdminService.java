package cn.edu.hbuas.etd.service;
import cn.edu.hbuas.etd.base.BaseService;
import cn.edu.hbuas.etd.po.Admin;

/**
 * @ClassName:  
 * @Description: 
 * @author  - - admin
 * @date - 2019年05月21日 15时41分10秒
 */
public interface AdminService extends BaseService<Admin>{
	

}
