package cn.edu.hbuas.etd.service;
import cn.edu.hbuas.etd.base.BaseService;
import cn.edu.hbuas.etd.po.College;

/**
 * @ClassName:  
 * @Description: 
 * @author  - - admin
 * @date - 2019年05月21日 15时41分13秒
 */
public interface CollegeService extends BaseService<College>{
	

}
