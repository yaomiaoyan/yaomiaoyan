/**
 * @ClassName:  
 * @Description: 
 * @author administrator
 * @date - 2019年05月21日 15时41分10秒
 */
package cn.edu.hbuas.etd.service.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.hbuas.etd.base.BaseDao;
import cn.edu.hbuas.etd.base.BaseServiceImpl;
import cn.edu.hbuas.etd.mapper.AdminMapper;
import cn.edu.hbuas.etd.po.Admin;
import cn.edu.hbuas.etd.service.AdminService;

/**
 * @ClassName:  
 * @Description: 
 * @author  - - admin
 * @date - 2019年05月21日 15时41分10秒
 */

@Service
public class AdminServiceImpl extends BaseServiceImpl<Admin> implements AdminService{
	 
	
	@Autowired
	private AdminMapper adminMapper;
	@Override
	public BaseDao<Admin> getBaseDao() {
		return adminMapper;
	}

}
