/**
 * @ClassName:  
 * @Description: 
 * @author administrator
 * @date - 2019年05月21日 15时41分12秒
 */
package cn.edu.hbuas.etd.service.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.hbuas.etd.base.BaseDao;
import cn.edu.hbuas.etd.base.BaseServiceImpl;
import cn.edu.hbuas.etd.mapper.AnnouncementMapper;
import cn.edu.hbuas.etd.po.Announcement;
import cn.edu.hbuas.etd.service.AnnouncementService;

/**
 * @ClassName:  
 * @Description: 
 * @author  - - admin
 * @date - 2019年05月21日 15时41分12秒
 */

@Service
public class AnnouncementServiceImpl extends BaseServiceImpl<Announcement> implements AnnouncementService{
	 
	
	@Autowired
	private AnnouncementMapper announcementMapper;
	@Override
	public BaseDao<Announcement> getBaseDao() {
		return announcementMapper;
	}

}
