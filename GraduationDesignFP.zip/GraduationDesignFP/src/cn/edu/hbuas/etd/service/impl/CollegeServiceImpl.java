/**
 * @ClassName:  
 * @Description: 
 * @author administrator
 * @date - 2019年05月21日 15时41分13秒
 */
package cn.edu.hbuas.etd.service.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.hbuas.etd.base.BaseDao;
import cn.edu.hbuas.etd.base.BaseServiceImpl;
import cn.edu.hbuas.etd.mapper.CollegeMapper;
import cn.edu.hbuas.etd.po.College;
import cn.edu.hbuas.etd.service.CollegeService;

/**
 * @ClassName:  
 * @Description: 
 * @author  - - admin
 * @date - 2019年05月21日 15时41分13秒
 */

@Service
public class CollegeServiceImpl extends BaseServiceImpl<College> implements CollegeService{
	 
	
	@Autowired
	private CollegeMapper collegeMapper;
	@Override
	public BaseDao<College> getBaseDao() {
		return collegeMapper;
	}

}
