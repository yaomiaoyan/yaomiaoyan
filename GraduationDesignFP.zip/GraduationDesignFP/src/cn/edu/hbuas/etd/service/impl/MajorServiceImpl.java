/**
 * @ClassName:  
 * @Description: 
 * @author administrator
 * @date - 2019年05月21日 15时41分13秒
 */
package cn.edu.hbuas.etd.service.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.hbuas.etd.base.BaseDao;
import cn.edu.hbuas.etd.base.BaseServiceImpl;
import cn.edu.hbuas.etd.mapper.MajorMapper;
import cn.edu.hbuas.etd.po.Major;
import cn.edu.hbuas.etd.service.MajorService;

/**
 * @ClassName:  
 * @Description: 
 * @author  - - admin
 * @date - 2019年05月21日 15时41分13秒
 */

@Service
public class MajorServiceImpl extends BaseServiceImpl<Major> implements MajorService{
	 
	
	@Autowired
	private MajorMapper majorMapper;
	@Override
	public BaseDao<Major> getBaseDao() {
		return majorMapper;
	}

}
