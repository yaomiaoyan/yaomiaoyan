/**
 * @ClassName:  
 * @Description: 
 * @author administrator
 * @date - 2019年05月21日 15时41分13秒
 */
package cn.edu.hbuas.etd.service.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.hbuas.etd.base.BaseDao;
import cn.edu.hbuas.etd.base.BaseServiceImpl;
import cn.edu.hbuas.etd.mapper.ProjectMapper;
import cn.edu.hbuas.etd.po.Project;
import cn.edu.hbuas.etd.service.ProjectService;

/**
 * @ClassName:  
 * @Description: 
 * @author  - - admin
 * @date - 2019年05月21日 15时41分13秒
 */

@Service
public class ProjectServiceImpl extends BaseServiceImpl<Project> implements ProjectService{
	 
	
	@Autowired
	private ProjectMapper projectMapper;
	@Override
	public BaseDao<Project> getBaseDao() {
		return projectMapper;
	}

}
