/**
 * @ClassName:  
 * @Description: 
 * @author administrator
 * @date - 2019年05月21日 15时41分13秒
 */
package cn.edu.hbuas.etd.service.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.hbuas.etd.base.BaseDao;
import cn.edu.hbuas.etd.base.BaseServiceImpl;
import cn.edu.hbuas.etd.mapper.StudentMapper;
import cn.edu.hbuas.etd.po.Student;
import cn.edu.hbuas.etd.service.StudentService;

/**
 * @ClassName:  
 * @Description: 
 * @author  - - admin
 * @date - 2019年05月21日 15时41分13秒
 */

@Service
public class StudentServiceImpl extends BaseServiceImpl<Student> implements StudentService{
	 
	
	@Autowired
	private StudentMapper studentMapper;
	@Override
	public BaseDao<Student> getBaseDao() {
		return studentMapper;
	}

}
