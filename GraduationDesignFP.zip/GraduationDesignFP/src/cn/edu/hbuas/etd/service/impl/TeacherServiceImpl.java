/**
 * @ClassName:  
 * @Description: 
 * @author administrator
 * @date - 2019年05月21日 15时41分13秒
 */
package cn.edu.hbuas.etd.service.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.hbuas.etd.base.BaseDao;
import cn.edu.hbuas.etd.base.BaseServiceImpl;
import cn.edu.hbuas.etd.mapper.TeacherMapper;
import cn.edu.hbuas.etd.po.Teacher;
import cn.edu.hbuas.etd.service.TeacherService;

/**
 * @ClassName:  
 * @Description: 
 * @author  - - admin
 * @date - 2019年05月21日 15时41分13秒
 */

@Service
public class TeacherServiceImpl extends BaseServiceImpl<Teacher> implements TeacherService{
	 
	
	@Autowired
	private TeacherMapper teacherMapper;
	@Override
	public BaseDao<Teacher> getBaseDao() {
		return teacherMapper;
	}

}
