package cn.edu.hbuas.etd.utils;

public class ItemDto {

	private Integer itemId;
	
	private Double itemRecommendDegree;

	public Integer getItemId() {
		return itemId;
	}

	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}

	public double getItemRecommendDegree() {
		return itemRecommendDegree;
	}

	public void setItemRecommendDegree(double itemRecommendDegree) {
		this.itemRecommendDegree = itemRecommendDegree;
	}
	
	
}
